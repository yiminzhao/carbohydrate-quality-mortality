****import data****
import sas using "D:\code and results\article\CARBON-CVD\AARP\yimin_zhao_09oct2023.sas7bdat", clear
cd "D:\code and results\article\CARBON-CVD\AARP"
*******************************************************
* exclusion log: initialize
*******************************************************
tempname exclog
tempfile exclogfile

postfile `exclog' ///
    str80 step ///
    long n_before ///
    long n_dropped ///
    long n_after ///
    using `exclogfile', replace

capture program drop log_drop
program define log_drop
    syntax , STEP(string) HANDLE(name)

    quietly count
    local n_before = r(N)

    quietly count if __dropflag__ == 1
    local n_dropped = r(N)

    drop if __dropflag__ == 1

    quietly count
    local n_after = r(N)

    post `handle' (`"`step'"') (`n_before') (`n_dropped') (`n_after')

    drop __dropflag__
end

quietly count
post `exclog' (`"Initial sample after import"') (r(N)) (0) (r(N))
************************************1. subject exclusion************************************
destring AARP_ID, gen(AARPID)
ren NDI_ICD10_RECODE_113 cause_of_ICD10
ren NDI_ICD9_RECODE_72 cause_of_ICD9
ren PERSONYRS_ALLCAUSEMORT personyear
ren CALORIES energy
ren SEX sex
ren ENTRY_AGE age
ren BMI_CUR bmi
****************************************carbohydrate************************************
ren CARBOHYDRATE carbohydrate
ren FIBER_CSFII total_fiber
ren FATTOTAL totalfat
ren PROTEIN totalprotein
gen fat_p = (totalfat * 9 / energy) * 100
gen protein_p = (totalprotein * 4 / energy) * 100
gen carb_p = (carbohydrate * 4 / energy) * 100
gen fiber_p = (total_fiber * 4 / energy) * 100
gen carb_fiber = carbohydrate / total_fiber
// centile carb_fiber, centile(0.1 99.9)
// local p1 = r(c_1)
// local p99 = r(c_2)
// drop if (carb_fiber <= `p1' | carb_fiber >= `p99') & !missing(carb_fiber)
centile carb_fiber, centile(0.1 99.9)
local p1 = r(c_1)
local p99 = r(c_2)
*sex-specific quintile
local scores carb_p fiber_p carb_fiber 
foreach score in `scores' {
    egen `score'_cat = cut(`score'), group(5)
    egen q10 = pctile(`score'), p(10)
    egen q90 = pctile(`score'), p(90)
    gen z_`score' = (`score' - q10) / (q90 - q10)
    drop q10 q90
}


gen byte __dropflag__ = (FL_PROXY == 1)
log_drop, step("Exclude: proxy respondents") handle(`exclog')

gen byte __dropflag__ = (sex == 0 & (energy < 800 | energy > 4200)) | ///
                        (sex == 1 & (energy < 600 | energy > 3500))
log_drop, step("Exclude: extreme energy intake") handle(`exclog')

gen byte __dropflag__ = (carb_fiber <= `p1' | carb_fiber >= `p99') & !missing(carb_fiber)
log_drop, step("Exclude: carb_fiber outside 0.1th-99.9th percentile") handle(`exclog')

gen byte __dropflag__ = (bmi > 45 | bmi < 15)
log_drop, step("Exclude: abnormal BMI") handle(`exclog')

gen ersd_baseline = 0
replace ersd_baseline = 1 if RENAL==1
gen byte __dropflag__ = (ersd_baseline == 1)
log_drop, step("Exclude: ersd_baseline") handle(`exclog')

gen byte __dropflag__ = (SELF_BREAST == 1 | SELF_CANCER == 1 | SELF_COLON == 1 | ///
                         SELF_OTHER == 1 | SELF_PROSTATE == 1)
log_drop, step("Exclude: baseline cancer") handle(`exclog')

gen byte __dropflag__ = (STROKE == 1 | HEART == 1)
log_drop, step("Exclude: baseline CVD") handle(`exclog')

gen byte __dropflag__ = (HEALTH == 5)
log_drop, step("Exclude: poor baseline health") handle(`exclog')

su AARPID
*diabetes
*any diabetes, E10-E14

************************************2. rename and label covariates************************************
*covariates: age group 
*age category
ren AGECAT age_cat
tab age_cat
gen age_int = 0
replace age_int =1 if age >= 60
tab age_int
gen currentage = age + personyear

*BMI, quintiles
summarize bmi, detail
replace bmi = r(p50) if bmi == .
gen bmi_cat = 9
replace bmi_cat = 1 if bmi < 18.5
replace bmi_cat = 2 if bmi < 25 & bmi >= 18.5
replace bmi_cat = 3 if bmi < 30 & bmi >= 25
replace bmi_cat = 4 if bmi >= 30
tab bmi_cat
gen bmi_int = 1
replace bmi_int = 0 if bmi >= 18.5 & bmi < 25
tab bmi_int

*education
ren EDUCM education
*label define educationlabel 1 "< 8 years" 2 "8-11 years" 3 "12 years or completed high school" 4 "post-high school or some college" 5 "college and post graduate" 9 "unkonwn"
*label values education educationlabel
gen education_status = 9
replace education_status = 1 if education == 4 | education == 5
tab education_status
*1 = less than 8 years (n = 4,685) 2 = 8-11 years (n = 31,378) 3 = 12 years or completed high school (n = 111,530) 
*4 = post-high school or some college (n = 186,023) 5 = college and post graduate (n = 215,808) 9 = unknown (16,983)
gen education_int = 0
replace education_int = 1 if education_status == 1
*label define educationlabel2 0 "High school or below" 1 "College or above"
*label values education_int educationlabel2
tab education_int

*alcohol, categorized into sex-specific quintiles
 ren ALCOHOL_ALC_DRINKS alcohol
summarize alcohol, detail
replace alcohol = r(p50) if alcohol == .
gen alcohol_int = 1
replace alcohol_int = 0 if alcohol < 22 & sex == 0
replace alcohol_int = 0 if alcohol < 15 & sex == 1
tab alcohol_int


*physical activity, Physical activity ≥ 20 minutes (in the past 12 months) that caused increases in breathing or heart rate, or worked up a sweat.
ren PHYSIC pa
summarize pa, detail
replace pa = r(p50) if pa == .
gen pa_cat = 9
replace pa_cat = 1 if pa == 1 | pa == 0
replace pa_cat = 2 if pa == 2
replace pa_cat = 3 if pa == 3 | pa == 4
replace pa_cat = 4 if pa == 5
*label define pa_label 1 "never/rarely" 2 "< 3 times per month" 3 "1-4 times per week" 4 ">= 5 times per week" 9 "unknown"
*label values pa_cat pa_label
tab pa_cat
gen pa_int = 0
replace pa_int = 1 if pa_cat == 3 | pa_cat == 4
*label define pa_label2 0 "< 1 times per week" 1 ">= 1 times per week"
*label values pa_int pa_label2
tab pa_int

*race/ethnicity
gen race = 9
replace race = 1 if RACEM == 1
replace race = 2 if RACEM == 2
replace race = 3 if RACEM == 3 | RACEM == 4 | RACEM == 5 | RACEM == 6
*label define race_label 1 "non-Hispanic white" 2 "non-Hispanic black" 3 "Other" 9 "unknown"
*label values race race_label
gen ethnicity_int =0
replace ethnicity_int = 1 if RACEM == 1
*label define race_label2 1 "non-Hispanic white" 0 "Other"
*label values race_int race_label2
tab ethnicity_int

*Smoking status
gen smoking_status = 9
replace smoking_status = 0 if SMOKE_FORMER == 0
gen smoking_int = 1
replace smoking_int = 0 if smoking_status == 0
*label define smokinglabel2 0 "Never" 1 "Former/Current"
*label values smoking_int smokinglabel2
tab smoking_int

*Marital status
gen marriage_status = 9
replace marriage_status = 1 if marriage == 1
gen marriage = 0
replace marriage = 1 if marriage_status == 1
*label define marriagelabel 1 "Married" 2 "Not married"
*label values marriage marriagelabel
tab marriage
// *energy intake, in quintiles
// egen male_energy_cat = cut(energy) if sex == 0, group(5) 
// egen female_energy_cat = cut(energy) if sex == 1, group(5)
// gen energy_cat =.
// replace energy_cat = male_energy_cat if male_energy_cat !=.
// replace energy_cat = female_energy_cat if female_energy_cat !=.
// tab energy_cat
// tab energy_cat sex
rename HEI2015_TOTAL_SCORE HEISCORE
summarize HEISCORE, detail
replace HEISCORE = r(p50) if HEISCORE == .


****************************************3. death identification************************************
*total mortality
gen total_death = 0
replace total_death = 1 if substr(cause_of_ICD9,1,1) != ""
replace total_death = 1 if substr(cause_of_ICD10,1,1) != ""
tab total_death
*total CVD mortality
gen cvd_death = 0
gen cause_of_ICD10_num = real(cause_of_ICD10)
gen cause_of_ICD9_num = real(cause_of_ICD9)
replace cvd_death = 1 if inrange(cause_of_ICD10_num, 053, 074) | inrange(cause_of_ICD9_num, 300, 490)
tab cvd_death
*nonCVD mortality
gen nonCVD_death = 0
replace nonCVD_death = 1 if cvd_death == 0 & total_death == 1

* 9. 保存结果
***********************************202601 SMuRF***********************************
*hypertension
ren RF_Q47_1 rawhyper
gen byte hypertension = 0
replace hypertension = 1 if rawhyper == "1"
tab hypertension

*diabetes
gen diabetes_baseline = 0
replace diabetes_baseline = 1 if DIABETES == 1
tab diabetes_baseline

*current smoker
gen current_smoker = 0
replace current_smoker = 1 if SMOKE_FORMER == 2
tab current_smoker
gen smurf = hypertension + diabetes_baseline + current_smoker
tab smurf
gen smurf_cat = 0
replace smurf_cat = 1 if smurf == 1
replace smurf_cat = 2 if smurf >= 2
// keep n_eid smurf hypertension diabetes current_smoker smurf_cat

save"alldata_new.dta", replace
*******************************************************
* close log and export exclusion summary
*******************************************************
postclose `exclog'
preserve
use `exclogfile', clear
gen step_order = _n
order step_order step n_before n_dropped n_after
list, noobs sep(0)
export excel using "sample_exclusion_summary.xlsx", ///
    firstrow(variables) replace
restore

