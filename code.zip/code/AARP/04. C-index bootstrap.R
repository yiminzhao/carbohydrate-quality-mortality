library(haven)       
library(survival)    
library(dplyr)       
library(rms)         
library(tidyr)       
library(writexl)     
library(lubridate)   
start_time <- Sys.time()
setwd("D:/code and results/article/CARBON-CVD/AARP")
data_raw <- read_dta("alldata_new.dta")

covariates <- c("sex", "education_int", "alcohol_int", 
                "pa_int", "smoking_int", "ethnicity_int", 
                "energy", "fat_p", "protein_p","hypertension","diabetes_baseline")
outcomes <- c("cvd_death", "total_death", "nonCVD_death")
#outcomes <- c("cvd_death")
exposures <- c("carb_p", "fiber_p") 
ref_base  <- "carb_fiber"
N_BOOT <- 1000 # number of bootstrapping
set.seed(12345) 
results_list <- list()
# categorical and continuous model
get_formula <- function(type, exp_var, covs, data) {
  exp_var <- trimws(exp_var)
  if (type == "cat") {
    f_str <- paste0("Surv(time, status) ~ as.factor(", exp_var, "_cat) + ", paste(covs, collapse = "+")) # formula for categorical model
  } 
  else if (type == "con") {
    f_str <- paste0("Surv(time, status) ~ z_", exp_var, " + ", paste(covs, collapse = "+")) # formula for continuous model
  }
  f_str <- paste0(f_str, " + strata(age_cat)")
  return(as.formula(f_str)) 
}

# loop between each outcome
for (outcome in outcomes) {
  cat(paste0("\nProcessing Outcome: ", outcome, "...\n"))
  
  # data cleaning, date and event
  df_clean <- data_raw %>%
    mutate(#base_d  = baseline_date,
           #event_d = get(paste0(outcome, "_date")),
           time = personyear,
           status = get(outcome))
  
  df_clean <- df_clean %>%
    filter(time > 0) %>%
    drop_na(all_of(c(covariates, "age_cat",
                     paste0(ref_base, "_cat"), paste0("z_", ref_base),
                     paste0(exposures, "_cat"), paste0("z_", exposures))))
  

  # loop between cat and con models
  for (type in c("cat", "con")) {
    cat(paste0("  > Bootstrapping ", type, " model (0/", N_BOOT, ")... "))
    
    boot_matrix <- matrix(NA, nrow = N_BOOT, ncol = 5) # store the results of each bootstrap
    colnames(boot_matrix) <- c("C_ref", "C_carb", "Diff_carb", "C_fiber", "Diff_fiber") # column name of boot_matrix
    pb <- txtProgressBar(min = 0, max = N_BOOT, style = 3) # display the progress of bootstrapping

    # bootstrapping
    for (b in 1:N_BOOT) {
      indices <- sample(1:nrow(df_clean), nrow(df_clean), replace = TRUE) # ensure equal sample size in each sampling
      boot_data <- df_clean[indices, ] # new dataset after sampling for subsequent cox regression
      
      # carb_fiber, the reference
      form_ref <- get_formula(type, ref_base, covariates, boot_data) # formula of cox regression
      fit_ref <- coxph(form_ref, data = boot_data)
      c_ref <- concordance(fit_ref)$concordance # calculating the c-index of carb_fiber
      boot_matrix[b, "C_ref"] <- c_ref
      
      # carb_p
      form_carb <- get_formula(type, "carb_p", covariates, boot_data) # formula of cox regression
      fit_carb <- coxph(form_carb, data = boot_data)
      c_carb <- concordance(fit_carb)$concordance
      boot_matrix[b, "C_carb"] <- c_carb
      boot_matrix[b, "Diff_carb"] <- c_carb - c_ref # difference in c-index 
      
      #fiber_p
      form_fiber <- get_formula(type, "fiber_p", covariates, boot_data) # formula of cox regression
      fit_fiber <- coxph(form_fiber, data = boot_data)
      c_fiber <- concordance(fit_fiber)$concordance # calculating the c-index
      boot_matrix[b, "C_fiber"] <- c_fiber # store the c-index in the boot_matrix
      boot_matrix[b, "Diff_fiber"] <- c_fiber - c_ref # store the difference in c-index in the boot_matrix
      
      setTxtProgressBar(pb, b) # display the progress of bootstrapping
    }
    close(pb)
    
    boot_df <- as.data.frame(boot_matrix) # convert the matrix to data frame
    
    # normal-based CIs
    # get_stats <- function(vec, is_diff = FALSE) {
    #   est <- mean(vec, na.rm=TRUE)
    #   se  <- sd(vec, na.rm=TRUE)
    #   lb  <- est - 1.96 * se # normal-based CIs
    #   ub  <- est + 1.96 * se
    #   z   <- est / se
    #   p   <- 2 * (1 - pnorm(abs(z)))
    #   est_str <- sprintf("%.3f (%.3f, %.3f)", est, lb, ub)
    #   p_str   <- sprintf("%.3f", p)
    #   if (is_diff) return(list(str = est_str, p = p_str))
    #   return(est_str)
    # }
    
    # percentile-based CIs  
    get_stats <- function(vec, is_diff = FALSE) {
      est <- median(vec, na.rm = TRUE) # the median of the 1000 c-index after bootstrapping
      ci <- quantile(vec, probs = c(0.025, 0.975), na.rm = TRUE)
      lb <- ci[1] # the 2.5th percentile
      ub <- ci[2] # the 97.5th percentile

      # if is_diff = T, calculate the p value for difference in c-index
      if (is_diff) {
        if (est > 0) {
          prop_opposite <- mean(vec <= 0, na.rm = TRUE) # the proportion of samples that cross 0 in the opposite direction of the estimate
        } else {
          prop_opposite <- mean(vec >= 0, na.rm = TRUE)
        }

        p <- 2 * prop_opposite # Two-sided p-value
        # Cap p-value at 1.0
        p <- min(p, 1.0)
      } 
       else {
         se <- sd(vec, na.rm = TRUE)
         z  <- est / se
         p  <- 2 * (1 - pnorm(abs(z)))
       }
      
      est_str <- sprintf("%.3f (%.3f, %.3f)", est, lb, ub)
      p_str   <- sprintf("%.3f", p)
      
      if (is_diff) return(list(str = est_str, p = p_str))
      return(est_str)
    }
     
    c_ref_str   <- get_stats(boot_df$C_ref) # c-index of carb_fiber
    c_carb_str  <- get_stats(boot_df$C_carb)
    diff_carb   <- get_stats(boot_df$Diff_carb, is_diff = TRUE)
    c_fiber_str <- get_stats(boot_df$C_fiber)
    diff_fiber  <- get_stats(boot_df$Diff_fiber, is_diff = TRUE)

    results_list[[length(results_list) + 1]] <- data.frame(Outcome = outcome, Model_Type = type, Exposure = "Ratio", C_Index = c_ref_str, Diff = "-", P_Value = "-")
    results_list[[length(results_list) + 1]] <- data.frame(Outcome = outcome, Model_Type = type, Exposure = "Total Carb", C_Index = c_carb_str, Diff = diff_carb$str, P_Value = diff_carb$p)
    results_list[[length(results_list) + 1]] <- data.frame(Outcome = outcome, Model_Type = type, Exposure = "Total Fiber", C_Index = c_fiber_str, Diff = diff_fiber$str, P_Value = diff_fiber$p)
  }
}

end_time <- Sys.time()

full_df <- bind_rows(results_list)

final_table <- full_df %>%
  pivot_wider(id_cols = c(Outcome, Exposure),
              names_from = Model_Type,
              values_from = c(C_Index, Diff, P_Value),
              names_glue = "{Model_Type}_{.value}") %>%
  select( Outcome, Exposure,
          `Harrell's C (Cat)` = cat_C_Index, `Diff vs Ratio (Cat)` = cat_Diff, `P (Cat)` = cat_P_Value,
          `Harrell's C (Con)` = con_C_Index, `Diff vs Ratio (Con)` = con_Diff, `P (Con)` = con_P_Value) %>%
  arrange(Outcome, match(Exposure, c("Ratio", "Total Carb", "Total Fiber")))

print(head(final_table))
write_xlsx(final_table, "Results_new.xlsx")

cat(paste0("\nSuccess! Analysis finished in ", round(difftime(end_time, start_time, units="mins"), 2), " minutes."))