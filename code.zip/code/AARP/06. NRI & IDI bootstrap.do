cd "D:\code and results\article\CARBON-CVD\AARP"
use "alldata_new.dta", clear
capture program drop boot_nri_idi
program define boot_nri_idi, rclass
    syntax, ref_var(string) tar_var(string) covariates(string) time_horizon(real)

    quietly stcox `ref_var' `covariates', strata(age_cat)
    tempvar xb_ref base_surv_ref risk_ref
    predict `xb_ref', xb
    predict double `base_surv_ref', basesurv
    quietly sum `base_surv_ref' if _t <= `time_horizon'
    scalar S0_ref = r(min)
    if missing(S0_ref) scalar S0_ref = 0 
    gen `risk_ref' = 1 - (S0_ref)^exp(`xb_ref')

    quietly stcox `tar_var' `covariates', strata(age_cat)
    tempvar xb_tar base_surv_tar risk_tar
    predict `xb_tar', xb
    predict double `base_surv_tar', basesurv    
    quietly sum `base_surv_tar' if _t <= `time_horizon'
    scalar S0_tar = r(min)
    if missing(S0_tar) scalar S0_tar = 0
    gen `risk_tar' = 1 - (S0_tar)^exp(`xb_tar')

    tempvar is_case_boot is_control_boot diff_risk    
    gen `is_case_boot' = (_d == 1 & _t <= `time_horizon')
    gen `is_control_boot' = (_t >= `time_horizon' - 0.1)     
    gen `diff_risk' = `risk_tar' - `risk_ref'

    * IDI
    quietly sum `diff_risk' if `is_case_boot' == 1
    scalar mean_case = r(mean)
    quietly sum `diff_risk' if `is_control_boot' == 1
    scalar mean_cont = r(mean)
    return scalar idi = mean_case - mean_cont

    * continuous NRI
    quietly count if `is_case_boot' == 1 & `diff_risk' > 0
    scalar n_up_case = r(N)
    quietly count if `is_case_boot' == 1 & `diff_risk' < 0
    scalar n_down_case = r(N)
    quietly count if `is_case_boot' == 1
    scalar N_case = r(N)

    quietly count if `is_control_boot' == 1 & `diff_risk' > 0
    scalar n_up_cont = r(N)
    quietly count if `is_control_boot' == 1 & `diff_risk' < 0
    scalar n_down_cont = r(N)
    quietly count if `is_control_boot' == 1
    scalar N_cont = r(N)
    
    if N_case > 0 & N_cont > 0 {
        return scalar nri = ((n_up_case/N_case) - (n_down_case/N_case)) + ///
                            ((n_down_cont/N_cont) - (n_up_cont/N_cont))
    }
    else {
        return scalar nri = .
    }
end

putexcel set "Results_new.xlsx", sheet("Table S6 NRI_IDI", replace) modify 
local x = 1
putexcel A`x'=("Table S6. Reclassification performance (Bootstrap Percentile CI)."), bold
local x=`x'+1
putexcel B`x'=("median follow-up") F`x'=("latest follow-up"), bold
local x=`x'+1
putexcel B`x'=("Categorical model") D`x'=("Continuous model") F`x'=("Categorical model") H`x'=("Continuous model")
local x=`x'+1
putexcel A`x'=("Outcome/Comparison")  
putexcel B`x'=("delta continous NRI, 95% CI") C`x'=("delta IDI, 95% CI") D`x'=("delta Continous NRI, 95% CI") E`x'=("delta IDI, 95% CI") 
putexcel F`x'=("delta Continous NRI, 95% CI") G`x'=("delta IDI, 95% CI") H`x'=("delta Continous NRI, 95% CI") I`x'=("delta IDI, 95% CI") 

local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension diabetes_baseline"
local outcomes "cvd_death total_death nonCVD_death"
*local outcomes "cvd_death"
local targets "carb_p fiber_p" 
*local targets "carb_p" 

foreach outcome of local outcomes {
    capture drop xb_* neg_xb_* sp_* cens is_case is_control
    stset currentage , id(AARPID) enter(age)  failure(`outcome' == 1)
    
    quietly su _t, d
    *latest follow-up time
    local time_horizon_max = r(max)
    *median follow-up time
    local time_horizon_med = r(p50)
    
    * loop through both time horizons
    foreach horizon in med max {        
        local current_time = `time_horizon_`horizon''
        
        foreach target of local targets {

            foreach model in cat con {    
            *foreach model in con {             
                if "`model'" == "cat" {
                    local ref_var "i.carb_fiber_cat"
                    local tar_var "i.`target'_cat"
                }
                if "`model'" == "con" {
                    local ref_var "c.z_carb_fiber"
                    local tar_var "c.z_`target'"
                }

                * Run Bootstrap
                bootstrap nri=r(nri) idi=r(idi), reps(10) seed(12345): ///
                    boot_nri_idi, ref_var("`ref_var'") tar_var("`tar_var'") covariates("`covariates'") time_horizon(`current_time')
                estat bootstrap, percentile
                matrix b = e(b)
                matrix ci = e(ci_percentile)
                
                * Extract
                local nri_val = b[1,1]                
                local nri_lb  = ci[1,1] 
                local nri_ub  = ci[2,1]

                local idi_val = b[1,2]                
                local idi_lb  = ci[1,2]
                local idi_ub  = ci[2,2]
                local nri_str = string(`nri_val', "%9.3f") + " (" + string(`nri_lb', "%9.3f") + ", " + string(`nri_ub', "%9.3f") + ")"
                local idi_str = string(`idi_val', "%9.3f") + " (" + string(`idi_lb', "%9.3f") + ", " + string(`idi_ub', "%9.3f") + ")"

                * Save to unique locals: e.g., nri_max_carb_p_cat
                local nri_`horizon'_`target'_`model' = "`nri_str'"
                local idi_`horizon'_`target'_`model' = "`idi_str'"

            }
        }
    }
    

    local x = `x' + 1
    putexcel A`x'=("`outcome'"), left   
    local x = `x' + 1
    putexcel A`x'=("Total Carb vs Ratio"), right
    putexcel B`x'=("`nri_max_carb_p_cat'") C`x'=("`idi_max_carb_p_cat'") D`x'=("`nri_max_carb_p_con'") E`x'=("`idi_max_carb_p_con'") ///
             F`x'=("`nri_med_carb_p_cat'") G`x'=("`idi_med_carb_p_cat'") H`x'=("`nri_med_carb_p_con'") I`x'=("`idi_med_carb_p_con'")
    local x = `x' + 1
    putexcel A`x'=("Total Fiber vs Ratio"), right
    putexcel B`x'=("`nri_max_fiber_p_cat'") C`x'=("`idi_max_fiber_p_cat'") D`x'=("`nri_max_fiber_p_con'") E`x'=("`idi_max_fiber_p_con'") ///
             F`x'=("`nri_med_fiber_p_cat'") G`x'=("`idi_med_fiber_p_cat'") H`x'=("`nri_med_fiber_p_con'") I`x'=("`idi_med_fiber_p_con'")
}