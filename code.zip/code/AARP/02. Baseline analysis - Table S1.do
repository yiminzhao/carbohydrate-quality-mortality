cd "D:\code and results\article\CARBON-CVD\AARP"
use "alldata_new.dta", clear
***********************************carbohydrate-to-fiber ratio**********************************************************
putexcel set "Results_new.xlsx", sheet("Table S1", replace) modify 
local x = 1
putexcel A`x'=("Table S1. Baseline characteristics of AARP participants stratified by carbohydrate-to-fiber ratio"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5")

forvalues i = 0/4 {
	qui su AARPID if carb_fiber_cat == `i'
	local num`i' = r(N)
}

*Carbohdyrate-to-fiber ratio
local item = "Carbohdyrate-to-fiber ratio, mean (SD)"
forvalues i = 0/4 {
	su carb_fiber if carb_fiber_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*age
local item = "Age, mean (SD), years"
forvalues i = 0/4 {
	qui su age if carb_fiber_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Men%
local item="Men, %"
forvalues i = 0/4 {
    qui su AARPID if sex == 0 & carb_fiber_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Healthy BMI
local item="Healthy BMI, %"
forvalues i = 0/4 {
	qui su AARPID if bmi_int == 0 & carb_fiber_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*British white
local item="British white, %"
forvalues i = 0/4 {
	qui su AARPID if ethnicity_int == 1 & carb_fiber_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Education
local item="College or university degree, %"
forvalues i = 0/4 {
	qui su AARPID if education_int == 1 & carb_fiber_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Never-smokers
local item="Never-smokers, %"
forvalues i = 0/4 {
	qui su AARPID if smoking_int == 0 & carb_fiber_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Excessive alcohol intake
local item="Excessive alcohol intake, %"
forvalues i = 0/4 {
    qui su AARPID if alcohol_int == 1  &  carb_fiber_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Adequate physical activity
local item="Adequate physical activity, %"
forvalues i = 0/4 {
    qui su AARPID if pa_int == 1 & carb_fiber_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Healthy eating index
// local item="Healthy eating index, mean (SD)"
// forvalues i = 0/4 {
// 	qui su ahei_total if carb_fiber_cat == `i'
//     local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Hypertension
local item="Hypertension, %"
forvalues i = 0/4 {
	qui su AARPID if hypertension == 1 & carb_fiber_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

// *Dyslipidemia
// local item="Dyslipidemia, %"
// forvalues i = 0/4 {
// 	qui su AARPID if dyslipidemia == 1 & carb_fiber_cat == `i'
// 	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*diabetes_baseline
local item="diabetes_baseline, %"
forvalues i = 0/4 {
	qui su AARPID if diabetes_baseline == 1 & carb_fiber_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*SMuRFless
local item="SMuRFless, %"
forvalues i = 0/4 {
	qui su AARPID if smurf == 0 & carb_fiber_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Total energy intake
local item="Total energy intake, mean (SD), kcal/day"
forvalues i = 0/4 {
	qui su energy if carb_fiber_cat == `i'
    local chara`i'=string(r(mean),"%9.0f")+" ("+string(r(sd),"%9.0f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Carbohydrate
local item = "Carbohydrate, mean (SD), % of energy"
forvalues i = 0/4 {
	su carb_p if carb_fiber_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Fiber
local item = "Fiber, mean (SD), % of energy"
forvalues i = 0/4 {
	su fiber_p if carb_fiber_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Fat
local item = "Fat, mean (SD), % of energy"
forvalues i = 0/4 {
	su fat_p if carb_fiber_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Protein
local item = "Protein, mean (SD), % of energy"
forvalues i = 0/4 {
	su protein_p if carb_fiber_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")


***********************************carbohydrat quantity**********************************************************
putexcel set "Results_new.xlsx", sheet("Table S2", replace) modify 
local x = 1
putexcel A`x'=("Table S2. Baseline characteristics of AARP participants stratified by total carbohydrate intake"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5")

forvalues i = 0/4 {
	qui su AARPID if carb_p_cat == `i'
	local num`i' = r(N)
}

*carbohydrate
local item = "Carbohydrate, mean (SD), % of energy"
forvalues i = 0/4 {
	su carb_p if carb_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*age
local item = "Age, mean (SD), years"
forvalues i = 0/4 {
	qui su age if carb_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Men%
local item="Men, %"
forvalues i = 0/4 {
    qui su AARPID if sex == 0 & carb_p_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Healthy BMI
local item="Healthy BMI, %"
forvalues i = 0/4 {
	qui su AARPID if bmi_int == 0 & carb_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*British white
local item="British white, %"
forvalues i = 0/4 {
	qui su AARPID if ethnicity_int == 1 & carb_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Education
local item="College or university degree, %"
forvalues i = 0/4 {
	qui su AARPID if education_int == 1 & carb_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Never-smokers
local item="Never-smokers, %"
forvalues i = 0/4 {
	qui su AARPID if smoking_int == 0 & carb_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Excessive alcohol intake
local item="Excessive alcohol intake, %"
forvalues i = 0/4 {
    qui su AARPID if alcohol_int == 1  &  carb_p_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Adequate physical activity
local item="Adequate physical activity, %"
forvalues i = 0/4 {
    qui su AARPID if pa_int == 1 & carb_p_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

// *Healthy eating index
// local item="Healthy eating index, mean (SD)"
// forvalues i = 0/4 {
// 	qui su ahei_total if carb_p_cat == `i'
//     local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Hypertension
local item="Hypertension, %"
forvalues i = 0/4 {
	qui su AARPID if hypertension == 1 & carb_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

// *Dyslipidemia
// local item="Dyslipidemia, %"
// forvalues i = 0/4 {
// 	qui su AARPID if dyslipidemia == 1 & carb_p_cat == `i'
// 	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*diabetes_baseline
local item="diabetes_baseline, %"
forvalues i = 0/4 {
	qui su AARPID if diabetes_baseline == 1 & carb_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*SMuRFless
local item="SMuRFless, %"
forvalues i = 0/4 {
	qui su AARPID if smurf == 0 & carb_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Total energy intake
local item="Total energy intake, mean (SD), kcal/day"
forvalues i = 0/4 {
	qui su energy if carb_p_cat == `i'
    local chara`i'=string(r(mean),"%9.0f")+" ("+string(r(sd),"%9.0f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Fat
local item = "Fat, mean (SD), % of energy"
forvalues i = 0/4 {
	su fat_p if carb_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Protein
local item = "Protein, mean (SD), % of energy"
forvalues i = 0/4 {
	su protein_p if carb_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")


************************************fiber quantity**********************************************************
putexcel set "Results_new.xlsx", sheet("Table S3", replace) modify 
local x = 1
putexcel A`x'=("Table S3. Baseline characteristics of AARP participants stratified by fiber intake"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5")

forvalues i = 0/4 {
	qui su AARPID if fiber_p_cat == `i'
	local num`i' = r(N)
}

*Fiber
local item = "Fiber, mean (SD), % of energy"
forvalues i = 0/4 {
	su fiber_p if fiber_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*age
local item = "Age, mean (SD), years"
forvalues i = 0/4 {
	qui su age if fiber_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Men%
local item="Men, %"
forvalues i = 0/4 {
    qui su AARPID if sex == 0 & fiber_p_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Healthy BMI
local item="Healthy BMI, %"
forvalues i = 0/4 {
	qui su AARPID if bmi_int == 0 & fiber_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*British white
local item="British white, %"
forvalues i = 0/4 {
	qui su AARPID if ethnicity_int == 1 & fiber_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Education
local item="College or university degree, %"
forvalues i = 0/4 {
	qui su AARPID if education_int == 1 & fiber_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Never-smokers
local item="Never-smokers, %"
forvalues i = 0/4 {
	qui su AARPID if smoking_int == 0 & fiber_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Excessive alcohol intake
local item="Excessive alcohol intake, %"
forvalues i = 0/4 {
    qui su AARPID if alcohol_int == 1  &  fiber_p_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Adequate physical activity
local item="Adequate physical activity, %"
forvalues i = 0/4 {
    qui su AARPID if pa_int == 1 & fiber_p_cat == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

// *Healthy eating index
// local item="Healthy eating index, mean (SD)"
// forvalues i = 0/4 {
// 	qui su ahei_total if fiber_p_cat == `i'
//     local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Hypertension
local item="Hypertension, %"
forvalues i = 0/4 {
	qui su AARPID if hypertension == 1 & fiber_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

// *Dyslipidemia
// local item="Dyslipidemia, %"
// forvalues i = 0/4 {
// 	qui su AARPID if dyslipidemia == 1 & fiber_p_cat == `i'
// 	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*diabetes_baseline
local item="diabetes, %"
forvalues i = 0/4 {
	qui su AARPID if diabetes_baseline == 1 & fiber_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*SMuRFless
local item="SMuRFless, %"
forvalues i = 0/4 {
	qui su AARPID if smurf == 0 & fiber_p_cat == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`prop0'") C`x'=("`prop1'") D`x'=("`prop2'") E`x'=("`prop3'") F`x'=("`prop4'")

*Total energy intake
local item="Total energy intake, mean (SD), kcal/day"
forvalues i = 0/4 {
	qui su energy if fiber_p_cat == `i'
    local chara`i'=string(r(mean),"%9.0f")+" ("+string(r(sd),"%9.0f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Carbohydrate
local item = "Carbohydrate, mean (SD), % of energy"
forvalues i = 0/4 {
	su carb_p if fiber_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Fat
local item = "Fat, mean (SD), % of energy"
forvalues i = 0/4 {
	su fat_p if fiber_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")

*Protein
local item = "Protein, mean (SD), % of energy"
forvalues i = 0/4 {
	su protein_p if fiber_p_cat == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`chara0'") C`x'=("`chara1'") D`x'=("`chara2'") E`x'=("`chara3'") F`x'=("`chara4'")



**********************************************************************************************
putexcel set "Results_new.xlsx", sheet("Table S4", replace) modify 
local x = 1
putexcel A`x'=("Table S4. Baseline characteristics of AARP participants with and without diabetes_baseline at baseline"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("All participants") C`x'=("Without diabetes_baseline") D`x'=("With diabetes_baseline")

*Number of participants
local item = "Number of participants"
su AARPID
local numtotal = r(N)
forvalues i = 0/1 {
	qui su AARPID if diabetes_baseline == `i'
	local num`i' = r(N)
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`numtotal'") C`x'=("`num0'") D`x'=("`num1'") 

*Age
local item = "Age, mean (SD), years"
su age
local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
forvalues i = 0/1 {
	qui su age if diabetes_baseline == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

*Men%
local item="Men, %"
qui su AARPID if sex == 0
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
    qui su AARPID if sex == 0 & diabetes_baseline == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*Healthy BMI
local item="Healthy BMI, %"
qui su AARPID if bmi_int == 1
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
	qui su AARPID if bmi_int == 0 & diabetes_baseline == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*British white
local item="British white, %"
qui su AARPID if ethnicity_int == 1
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
	qui su AARPID if ethnicity_int == 1 & diabetes_baseline == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*Education
local item="College or university degree, %"
qui su AARPID if education_int == 1
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
	qui su AARPID if education_int == 1 & diabetes_baseline == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*Never-smokers
local item="Never-smokers, %"
qui su AARPID if smoking_int == 0
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
	qui su AARPID if smoking_int == 0 & diabetes_baseline == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*Excessive alcohol intake
local item="Excessive alcohol intake, %"
qui su AARPID if alcohol_int == 1
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
    qui su AARPID if alcohol_int == 1 & diabetes_baseline == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*Adequate physical activity
local item="Adequate physical activity, %"
qui su AARPID if pa_int == 1
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
    qui su AARPID if pa_int == 1 & diabetes_baseline == `i'
    local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

// *Healthy eating index
// local item="Healthy eating index, mean (SD)"
// qui su ahei_total
// local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
// forvalues i = 0/1 {
// 	qui su ahei_total if diabetes_baseline == `i'
//     local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

*Hypertension
local item="Hypertension, %"
qui su AARPID if hypertension == 1
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
	qui su AARPID if hypertension == 1 & diabetes_baseline == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

// *Dyslipidemia
// local item="Dyslipidemia, %"
// qui su AARPID if dyslipidemia == 1
// local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
// forvalues i = 0/1 {
// 	qui su AARPID if dyslipidemia == 1 & diabetes_baseline == `i'
// 	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
// }
// local x=`x'+1
// putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*SMuRFless
local item="SMuRFless, %"
qui su AARPID if smurf == 0
local proptotal= string(r(N)/`numtotal'*100,"%9.1f")
forvalues i = 0/1 {
	qui su AARPID if smurf == 0 & diabetes_baseline == `i'
	local prop`i'= string(r(N)/`num`i''*100,"%9.1f")
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`proptotal'") C`x'=("`prop0'") D`x'=("`prop1'")

*Total energy intake
local item="Total energy intake, mean (SD), kcal/day"
qui su energy
local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
forvalues i = 0/1 {
	qui su energy if diabetes_baseline == `i'
    local chara`i'=string(r(mean),"%9.0f")+" ("+string(r(sd),"%9.0f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

*Carbohydrate
local item = "Carbohydrate, mean (SD), % of energy"
qui su carb_p
local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
forvalues i = 0/1 {
	su carb_p if diabetes_baseline == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

*Fiber
local item = "Fiber, mean (SD), % of energy"
qui su fiber_p
local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
forvalues i = 0/1 {
	su fiber_p if diabetes_baseline == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

*Fat
local item = "Fat, mean (SD), % of energy"
qui su fat_p
local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
forvalues i = 0/1 {
	su fat_p if diabetes_baseline == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

*Protein
local item = "Protein, mean (SD), % of energy"
qui su protein_p
local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
forvalues i = 0/1 {
	su protein_p if diabetes_baseline == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

*Carbohydrate quality
local item = "Carbohydrate-to-fiber ratio, mean (SD)"
qui su carb_fiber
local charatotal=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
forvalues i = 0/1 {
	su carb_fiber if diabetes_baseline == `i'
    local chara`i'=string(r(mean),"%9.1f")+" ("+string(r(sd),"%9.1f") + ")"
}
local x=`x'+1
putexcel A`x'=("`item'") B`x'=("`charatotal'") C`x'=("`chara0'") D`x'=("`chara1'") 

