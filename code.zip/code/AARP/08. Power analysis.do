cd "D:\code and results\article\CARBON-CVD\AARP"
cd "D:\OneDrive\Project\2025carbohydrate\CARBON-CVD\AARP"
use "alldata_new.dta", clear

putexcel set "Results_new.xlsx", sheet("Power analysis", replace) modify 
local x = 1
putexcel A`x'=("Table . Power analysis in the AARP"), bold
local x=`x'+1
putexcel A`x'=("Outcome") B`x'=("Lower limit") C`x'=("Upper limit")

local outcomes "cvd_death total_death nonCVD_death"

foreach outcome of local outcomes {
    stset currentage , id(AARPID) enter(age)  failure(`outcome' == 1)
    stdes
    local prob = r(N_fail)/r(N_sub)
    local total_num = r(N_sub)
    local alpha_corrected = 0.05

    power cox, n(`total_num') power(0.8) eventprob(`prob') direction(upper) onesided
    matrix a = r(pss_table)
    local beta = a[1, 5]
    local hr_lower = string(exp(`beta' * (-1)),"%9.2f")
    local hr_upper = string(exp(`beta'),"%9.2f")

    local x=`x'+1
    putexcel A`x'=("`outcome'") B`x'=("`hr_lower'") C`x'=("`hr_upper'")

}


