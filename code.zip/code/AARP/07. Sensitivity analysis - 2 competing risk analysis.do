*Part 2: subdistribution hazard model: Competing risk analysis, cardiovascular mortality vs non-cardiovascular mortality
cd "D:\code and results\article\CARBON-CVD\AARP"
use "alldata_new.dta", clear

putexcel set "Sensitivity analysis.xlsx", sheet("Part 2", replace) modify 
local x = 1
putexcel A`x'=("Table . Competing risk analysis in the AARP"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5") G`x'=("HR per increment")

local covariates "sex i.age_cat education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension  diabetes_baseline"
local outcomes "cvd_death nonCVD_death"
local exposures "carb_fiber"

foreach exposure of local exposures{
    local x=`x'+1
    putexcel A`x'=("`exposure'"), left
    foreach outcome of local outcomes {
        local x=`x'+1
        putexcel A`x'=("`outcome'"), left
        preserve
        gen event_status = 2
        *primary event = 1, competing event = 2, censored/alive = 0
        replace event_status = 1 if `outcome' == 1
        replace event_status = 0 if total_death == 0
        tab event_status, m
        stset currentage , id(AARPID) enter(age)  failure(`outcome' == 1)
        stcrreg i.`exposure'_cat `covariates', compete(event_status == 2) 
        matrix a = r(table)
        *mat list a
        local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
        local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
        local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
        local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  
        stcrreg c.z_`exposure' `covariates', compete(event_status == 2) 
        matrix a = r(table)
        local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"
        local x=`x'+1
        putexcel A`x'=("SHR, 95% CI") B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'") 
        restore       
    }
}