*Part 3: Propensity score
cd "D:\code and results\article\CARBON-CVD\AARP"
use "alldata_new.dta", clear
// putexcel set "Sensitivity analysis.xlsx", sheet("Part 3", replace) modify 
// local x = 1
// putexcel A`x'=("Table . Propensity score analysis in the AARP"), bold
// local x=`x'+1
// putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5") G`x'=("HR per increment")

// local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension diabetes_baseline"
// local outcomes "cvd_death total_death nonCVD_death"
// local exposures "carb_fiber"

// *generalized propensity score estimation
// regress z_carb_fiber `covariates'
// predict treat_hat, xb
// predict residuals, residuals
// local sigma = e(rmse)
// gen gps = normalden(treat, treat_hat, `sigma')
// su treat
// gen marginal_density = normalden(treat, r(mean), r(sd))
// gen ipw = marginal_density / gps

// *weighting
// local x=`x'+1
// putexcel A`x'=("Propensity score weighting")
// foreach exposure of local exposures{
//     *local x=`x'+1
//     *putexcel A`x'=("`exposure'") 

//     foreach outcome of local outcomes {        
//         local x=`x'+1
//         putexcel A`x'=("`outcome'") 
//         preserve
//         stset currentage [pweight=ipw], id(AARPID) enter(age)  failure(`outcome' == 1)
//         // stset currentage , id(AARPID) enter(age)  failure(`outcome' == 1)

//         *stcox i.`exposure'_cat `covariates' [pweight = ipw], vce(robust)
//         stcox i.`exposure'_cat `covariates', strata(age_cat) vce(robust)
//         matrix a = r(table)
//         estat phtest, detail
//         local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
//         local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
//         local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
//         local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  

//         stcox c.z_`exposure' `covariates', strata(age_cat) vce(robust)
//         matrix a = r(table)
//         local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"

//         local x=`x'+1
//         putexcel A`x'=("`outcome', HR, 95% CI") B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'") 

//         restore
//     }
// }

// *stratification
// local x=`x'+1
// putexcel A`x'=("Propensity score stratification")
// foreach exposure of local exposures{
//     *local x=`x'+1
//     *putexcel A`x'=("`exposure'") 

//     foreach outcome of local outcomes {        
//         local x=`x'+1
//         putexcel A`x'=("`outcome'") 
//         preserve
        
//         qui xtile gps_strata = gps, nq(5)
//         stset currentage , id(AARPID) enter(age)  failure(`outcome' == 1)

//         stcox i.`exposure'_cat `covariates', strata(gps_strata age_cat) 
//         matrix a = r(table)
//         estat phtest, detail
//         local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
//         local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
//         local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
//         local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  

//         stcox c.z_`exposure' `covariates', strata(gps_strata age_cat)
//         matrix a = r(table)
//         local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"

//         local x=`x'+1
//         putexcel A`x'=("`outcome', HR, 95% CI") B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'") 

//         restore
//     }
// }

// *adjustment
// local x=`x'+1
// putexcel A`x'=("Propensity score adjustment")
// foreach exposure of local exposures{
//     *local x=`x'+1
//     *putexcel A`x'=("`exposure'") 

//     foreach outcome of local outcomes {        
//         local x=`x'+1
//         putexcel A`x'=("`outcome'") 
//         preserve
//         stset currentage , id(AARPID) enter(age)  failure(`outcome' == 1)

//         stcox i.`exposure'_cat `covariates' gps, strata(age_cat) 
//         matrix a = r(table)
//         estat phtest, detail
//         local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
//         local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
//         local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
//         local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  

//         stcox c.z_`exposure' `covariates' gps, strata(age_cat)
//         matrix a = r(table)
//         local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"

//         local x=`x'+1
//         putexcel A`x'=("`outcome', HR, 95% CI") B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'") 

//         restore
//     }
// }

putexcel set "Sensitivity analysis.xlsx", sheet("Part 3", replace) modify 
local x = 1
putexcel A`x'=("Table . Propensity score analysis in the AARP"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5") G`x'=("HR per increment")

local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension diabetes_baseline"
local outcomes "cvd_death total_death nonCVD_death"
local exposures "carb_fiber"
local cvd_death "Cardiovascular mortality"
local total_death "All-cause mortality"
local nonCVD_death "Non-cardiovascular mortality"

*generalized propensity score estimation
*regress z_carb_fiber `covariates'
*predict treat_hat, xb
*predict residuals, residuals
*local sigma = e(rmse)
*gen gps = normalden(treat, treat_hat, `sigma')
*su treat
*gen marginal_density = normalden(treat, r(mean), r(sd))
*gen ipw = marginal_density / gps
regress z_carb_fiber `covariates'
predict double treat_hat, xb
predict double resid, residuals
local sigma = e(rmse)
gen double gps = normalden(z_carb_fiber, treat_hat, `sigma')
su z_carb_fiber
gen double marginal_density = normalden(z_carb_fiber, r(mean), r(sd))
gen double ipw = marginal_density / gps
su ipw, d

********DEPRECATED******** weighting
local x=`x'+1
putexcel A`x'=("Propensity score weighting")
foreach exposure of local exposures{
    *local x=`x'+1
    *putexcel A`x'=("`exposure'") 

    foreach outcome of local outcomes {        
        *local x=`x'+1
        *putexcel A`x'=("`outcome'") 
        preserve
        stset currentage [pweight=ipw], id(AARPID) enter(age)  failure(`outcome' == 1)   
        stcox i.`exposure'_cat `covariates', strata(age_cat) vce(robust)
        matrix a = r(table)
        *estat phtest, detail
        local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
        local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
        local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
        local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  

        stcox c.z_`exposure' `covariates', strata(age_cat) vce(robust)
        matrix a = r(table)
        local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"

        local x=`x'+1
        putexcel A`x'=("``outcome'', HR, 95% CI"), right 
        putexcel B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'"), hcenter

        restore
    }
}



*stratification
local x=`x'+1
putexcel A`x'=("Propensity score stratification")
foreach exposure of local exposures{
    *local x=`x'+1
    *putexcel A`x'=("`exposure'") 

    foreach outcome of local outcomes {        
        *local x=`x'+1
        *putexcel A`x'=("`outcome'") 
        preserve
        
        qui xtile gps_strata = gps, nq(5)
       stset currentage , id(AARPID) enter(age)  failure(`outcome' == 1)
        stcox i.`exposure'_cat `covariates', strata(gps_strata age_cat) 
        matrix a = r(table)
        estat phtest, detail
        local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
        local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
        local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
        local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  

        stcox c.z_`exposure' `covariates', strata(gps_strata age_cat)
        matrix a = r(table)
        local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"

        local x=`x'+1
        putexcel A`x'=("``outcome'', HR, 95% CI"), right 
        putexcel B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'"), hcenter

        restore
    }
}

*adjustment
local x=`x'+1
putexcel A`x'=("Propensity score adjustment")
foreach exposure of local exposures{
    *local x=`x'+1
    *putexcel A`x'=("`exposure'") 

    foreach outcome of local outcomes {        
        *local x=`x'+1
        *putexcel A`x'=("`outcome'") 
        preserve
        stset currentage, id(AARPID) enter(age)  failure(`outcome' == 1)
        stcox i.`exposure'_cat `covariates' gps, strata(age_cat) 
        matrix a = r(table)
        estat phtest, detail
        local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
        local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
        local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
        local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  

        stcox c.z_`exposure' `covariates' gps, strata(age_cat)
        matrix a = r(table)
        local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"

        local x=`x'+1
        putexcel A`x'=("``outcome'', HR, 95% CI"), right 
        putexcel B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'"), hcenter

        restore
    }
}

clear all



