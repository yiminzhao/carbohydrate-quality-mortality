cd "D:\code and results\article\CARBON-CVD\UKB"
use "alldata_new.dta", clear
putexcel set "Results_new.xlsx", sheet("Table 1", replace) modify 
local x = 1
putexcel A`x'=("Table 1. Associations between carbohydrate quality and mortality in the UK Biobank"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5") G`x'=("E value") H`x'=("PAF")
putexcel I`x'=("HR per increment") J`x'=("E value") K`x'=("PAF") L`x'=("P for non-linearity")
local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"
local outcomes "cvd_death total_death nonCVD_death"
local exposures "carb_fiber carb_p fiber_p"
foreach exposure of local exposures{
    local x=`x'+1
    putexcel A`x'=("`exposure'"), left  

    foreach outcome of local outcomes {        
        local x=`x'+1
        putexcel A`x'=("`outcome'"), left 

        preserve
        stset `outcome'_date, id(n_eid) enter(baseline_date) origin(baseline_date) scale(365.25) failure(`outcome' == 1)

        *incidence
        forvalues i = 0/4{
            quietly stdes if `exposure'_cat == `i'
            local incidence`i' = string(r(N_fail)/r(tr)*100000,"%9.0fc")
        }
        local x=`x'+1
        putexcel A`x'=("Incidence"), right
        putexcel B`x'=("`incidence0'") C`x'=("`incidence1'") D`x'=("`incidence2'") E`x'=("`incidence3'") F`x'=("`incidence4'") 

        *Multivariate-adjusted HR
        stcox i.`exposure'_cat `covariates', strata(age_cat)
        matrix a = r(table)
        estat phtest, detail
        local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
        local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
        local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
        local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  
        local hr_value = a[1,5]
        local lcl_value = a[5,5]
        local ucl_value = a[6,5]
        *PAF
        punafcc, at(`exposure'_cat == 0)
        matrix d=r(cimat)
        local PAF1=string(d[1,1]*100,"%9.1f")+"% ("+string(d[1,2]*100,"%9.1f")+", "+string(d[1,3]*100,"%9.1f")+")"
        
        *evalue
        evalue hr `hr_value', lcl(`lcl_value') ucl(`ucl_value')
        local e_value = string(r(eval_est),"%9.2f")+" ("+string(r(eval_ci),"%9.2f")+")"
        di `e_value'

        *P for non-linearity
        centile `exposure', centile(10 30 50 70 90)
        * allow the entire range of the exposure is treated with equal sensitivity
        mkspline spl_`exposure' = `exposure', cubic nknots(5) knots(`r(r1)' `r(r2)' `r(r3)' `r(r4)' `r(r5)')
        quietly stcox spl_`exposure'* `covariates', strata(age_cat)
        estimates store nonlinear
        quietly stcox spl_`exposure'1 `covariates', strata(age_cat)
        estimates store linear
        lrtest nonlinear linear
        local p_nonlinear = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_nonlinear "<0.001"

        *HR per increment from 10th to 90th
        stcox c.z_`exposure' `covariates', strata(age_cat)
        matrix a = r(table)
        local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"
        local hr_value = a[1,1]
        local lcl_value = a[5,1]
        local ucl_value = a[6,1]
        *PAF
        punafcc, at(z_`exposure' == 0)
        matrix d=r(cimat)
        local PAF2=string(d[1,1]*100,"%9.1f")+"% ("+string(d[1,2]*100,"%9.1f")+", "+string(d[1,3]*100,"%9.1f")+")"
        *evalue
        evalue hr `hr_value', lcl(`lcl_value') ucl(`ucl_value')
        local e_value_c = string(r(eval_est),"%9.2f")+" ("+string(r(eval_ci),"%9.2f")+")"

        local x=`x'+1
        putexcel A`x'=("Multivariate-adjusted") , right
        putexcel B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`e_value'") H`x'=("`PAF1'")
        putexcel I`x'=("`HRc'") J`x'=("`e_value_c'") K`x'=("`PAF2'") L`x'=("`p_nonlinear'")
        restore
    }
}