*Part 3: Propensity score
cd "D:\code and results\article\CARBON-CVD\UKB"
use "alldata_new.dta", clear

putexcel set "Sensitivity analysis.xlsx", sheet("Part 4", replace) modify 
local x = 1
putexcel A`x'=("Table . Additionally adjusted for BMI in the UK Biobank"), bold
local x=`x'+1
putexcel A`x'=("Variable") B`x'=("Quintile 1") C`x'=("Quintile 2") D`x'=("Quintile 3") E`x'=("Quintile 4") F`x'=("Quintile 5") G`x'=("HR per increment")

local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"
local outcomes "cvd_death total_death nonCVD_death"
local exposures "carb_fiber"

*adjustment
local x=`x'+1
putexcel A`x'=("Additionally adjusted for BMI")
foreach exposure of local exposures{
    local x=`x'+1
    putexcel A`x'=("`exposure'") 

    foreach outcome of local outcomes {        
        local x=`x'+1
        putexcel A`x'=("`outcome'") 
        preserve
        stset `outcome'_date, id(n_eid) enter(baseline_date) origin(baseline_date) scale(365.25) failure(`outcome' == 1)

        stcox i.`exposure'_cat `covariates' bmi, strata(age_cat) 
        matrix a = r(table)
        estat phtest, detail
        local HR1 = string(a[1,2],"%9.2f")+" ("+string(a[5,2],"%9.2f")+", "+string(a[6,2],"%9.2f")+")"
        local HR2 = string(a[1,3],"%9.2f")+" ("+string(a[5,3],"%9.2f")+", "+string(a[6,3],"%9.2f")+")"
        local HR3 = string(a[1,4],"%9.2f")+" ("+string(a[5,4],"%9.2f")+", "+string(a[6,4],"%9.2f")+")"
        local HR4 = string(a[1,5],"%9.2f")+" ("+string(a[5,5],"%9.2f")+", "+string(a[6,5],"%9.2f")+")"  

        stcox c.z_`exposure' `covariates' bmi, strata(age_cat)
        matrix a = r(table)
        local HRc = string(a[1,1],"%9.2f")+" ("+string(a[5,1],"%9.2f")+", "+string(a[6,1],"%9.2f")+")"

        local x=`x'+1
        putexcel A`x'=("`outcome', HR, 95% CI") B`x'=("1.00") C`x'=("`HR1'") D`x'=("`HR2'") E`x'=("`HR3'") F`x'=("`HR4'") G`x'=("`HRc'") 

        restore
    }
}

