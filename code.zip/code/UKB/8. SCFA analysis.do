clear
cd "D:\code and results\article\CARBON-CVD\UKB"

local successful_i "" 
forvalues i = 1(1)22 {
    capture insheet using "scfa_grs\extractedSNP\snp_qc`i'.raw", clear
    if _rc == 0 { 
        sort iid
        save "scfa_grs\extractedSNP\snp_qc`i'.dta", replace
        local successful_i `successful_i' " "
        local successful_i `successful_i' `i'
    }
    else {
        di "failure"
    }
}
di `successful_i'

local first_file : word 1 of `successful_i'
di `first_file'
use "scfa_grs\extractedSNP\snp_qc`first_file'.dta", clear
local rest_files : list successful_i - first_file
di `rest_files'
foreach j of local rest_files {
    capture confirm file "scfa_grs\extractedSNP\snp_qc`j'.dta"
    if _rc == 0 {  
        di `j'
        qui merge 1:1 iid using "scfa_grs\extractedSNP\snp_qc`j'.dta", nogenerate
    }
}

destring, replace force
ren iid n_eid
drop if sex == 0
keep n_eid rs*

merge 1:1 n_eid using "alldata_new.dta", nogenerate keep(matched)
keep if ethnicity_int == 1

ds rs*
local vars `r(varlist)'
foreach var of local vars {
    qui summarize `var'
    scalar mean_val = r(mean)
    replace `var' = mean_val if missing(`var')
    scalar drop mean_val
}

*Reference:
*Prospective Analysis Reveals Associations between Carbohydrate Intakes, Genetic Predictors of Short-Chain Fatty Acid Synthesis, and Colorectal Cancer Risk
*Causal relationships among the gut microbiome, short-chain fatty acids and metabolic diseases
gen grs_butyrate = rs9423658_ca*0.33 + rs881390_ct*0.40 + rs2089222_ag*0.56 + rs9904981_ga*0.25 + rs10483112_tc*0.59 + rs12994030_tc*0.24 + rs2056208_tc*0.24 + rs10019739_ct*0.24 + rs7743827_ga*0.80
gen grs_propionate = rs7142308_ga*0.24 + rs12050534_ca*0.31 + rs1400566_gt*(-0.22)
gen grs_scfa = grs_butyrate + grs_propionate

local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"
local outcomes "cvd_death total_death nonCVD_death"
local exposures "carb_fiber carb_p fiber_p"
local scores "grs_butyrate grs_propionate grs_scfa"

foreach outcome of local outcomes{
    putexcel set "Results_new.xlsx", sheet("scfa_interaction_`outcome'", replace) modify
    local x = 1
    putexcel A`x'=("Table . Associations stratified by genetically predicted host short-chain fatty acid production in the UK Biobank"), left bold
    local x=`x'+1
    putexcel A`x'=(" ") B`x'=("HR, 95% CI") C`x'=("P for multiplicative interaction") D`x'=("P for additive interaction") E`x'=("RERI")
    putexcel G`x'=("HR") H`x'=("LCI") I`x'=("UCI") 

    stset `outcome'_date, id(n_eid) enter(baseline_date) origin(baseline_date) scale(365.25) failure(`outcome' == 1)

    foreach exposure of local exposures {
        local x=`x'+1
        putexcel A`x'=("`exposure'"), left

        foreach score of local scores {
            local x=`x'+1
            putexcel A`x'=("`score'"), left

            preserve

            qui su `score', d
            gen median_`score' = 1 if `score' >= r(p50)
            replace median_`score' = 0 if median_`score' == .
            
            quietly stcox c.z_`exposure' `covariates' if median_`score' == 1, strata(age_cat)
            matrix M = r(table)
            local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
            local HR = M[1,1]
            local LCI = M[5,1]
            local UCI = M[6,1]
            local x=`x'+1
            putexcel A`x'=("High PGS"), right
            putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
            quietly stcox c.z_`exposure' `covariates' if median_`score' == 0, strata(age_cat)
            matrix M = r(table)
            local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
            local HR = M[1,1]
            local LCI = M[5,1]
            local UCI = M[6,1]
            local x=`x'+1
            putexcel A`x'=("Low PGS"), right
            putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

            *multiplicative interaction
            quietly stcox c.z_`exposure'##i.median_`score' `covariates', strata(age_cat)
            estimates store A
            quietly stcox c.z_`exposure' i.median_`score' `covariates', strata(age_cat)
            estimates store B
            lrtest A B
            local p_multiplicative = string(r(p), "%9.3f")
            if r(p) < 0.001 local p_multiplicative "<0.001"

            *Additive interaction
            qui su z_`exposure', d
            gen median_`exposure' = 1 if z_`exposure' >= r(p50)
            replace median_`exposure' = 0 if median_`exposure' == .

            reri stcox median_`exposure' median_`score' `covariates', strata(age_cat)
            mat M = r(reri_table)
            local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
            local p_additive = string(M[4,4], "%9.3f")
            if M[4,4] < 0.001 local p_additive "<0.001"
            local x=`x'+1
            putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

            restore

        }
    }
}
