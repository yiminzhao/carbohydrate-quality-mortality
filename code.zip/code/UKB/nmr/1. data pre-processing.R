library(haven)
library(tidyverse)
library(data.table)
#library(irr)

rm(list = ls())

getwd()
setwd("D:/code and results/article/CARBON-CVD/UKB")

dt_raw <- read_dta("alldata_new.dta")

nmr_raw <- read_dta("nmr/nmr_release20.dta")
#field ID for all NMR metabolites
nmr_id <- c(20280, 20281, seq(23400, 23648, by = 1))
nmr_raw <- nmr_raw %>% 
  filter(n_eid %in% dt_raw$n_eid) %>% 
  select(n_eid, 
         matches(paste0(".*", paste(as.character(nmr_id), collapse = "|"), ".*")))
all_vars <- names(nmr_raw)
all_vars <- setdiff(all_vars, "n_eid")

# 1.correlation between baseliene and repeat visits
cor_results <- data.frame(nmr_id = numeric(0), 
                          cor_value = numeric(0), 
                          n_vars = numeric(0),
                          n_obs = numeric(0))

for(id in nmr_id) {
  id_vars <- all_vars[grepl(paste0("p", id, "_i"), all_vars)]
  temp_data <- nmr_raw %>%
    select(all_of(id_vars)) %>%
    na.omit() %>% 
    as.data.frame()
  n_obs <- nrow(temp_data)
  cor_matrix <- cor(temp_data, use = "pairwise.complete.obs")
  cor_value <- cor_matrix[lower.tri(cor_matrix)]
  
  cor_results <- rbind(cor_results, 
                       data.frame(nmr_id = id,
                                  cor_value = cor_value,
                                  n_vars = length(id_vars),
                                  n_obs = n_obs))
}

nmr_id <- cor_results %>%
  filter(cor_value > 0.3) %>%
  pull(nmr_id)

# removing metabolites that had low correlation between the baseline and repeat visit with a r <= 0.3
nmr_raw <- nmr_raw %>% 
  select(n_eid, 
         matches(paste0(".*", paste(as.character(nmr_id), collapse = "|"), ".*"))) %>% 
  select(-ends_with("_i1"))
  
# 2. missing rate for the remaining NMR metabolites
missing_rates <- data.frame(nmr_id = integer(),
                            variable = character(),
                            missing_count = integer(),
                            total_count = integer(),
                            missing_prop = numeric())

for(id in nmr_id) {
  id_vars <- names(nmr_raw)[grepl(as.character(id), names(nmr_raw))]
  for(var in id_vars) {
    missing_count <- sum(is.na(nmr_raw[[var]]))
    total_count <- nrow(nmr_raw)
    missing_prop <- sum(is.na(nmr_raw[[var]])) / nrow(nmr_raw) *100
    missing_rates <- rbind(missing_rates, 
                           data.frame(nmr_id = id,
                                      variable = var,
                                      missing_count = missing_count,
                                      total_count = total_count,
                                      missing_prop = missing_prop))
  }
}



# 3.replace missing values with median, log-transformed, and standardized
all_vars <- names(nmr_raw)
all_vars <- setdiff(all_vars, "n_eid")

for (id in all_vars){
  nmr_raw[[id]][is.na(nmr_raw[[id]])] <- median(nmr_raw[[id]], na.rm = TRUE)
  nmr_raw[[id]] <- log2(nmr_raw[[id]] + 1e-6)
  nmr_raw[[id]] <- (nmr_raw[[id]] - mean(nmr_raw[[id]])) / sd(nmr_raw[[id]])
}

dt_raw <- read_dta("alldata_new.dta")
dt_raw <- dt_raw %>% 
  select(n_eid, z_carb_fiber)

nmr <- inner_join(dt_raw, nmr_raw, by = "n_eid")

fwrite(nmr, "nmr/nmr.txt", sep = " ")

#dt <- fread("nmr/nmr.txt")





