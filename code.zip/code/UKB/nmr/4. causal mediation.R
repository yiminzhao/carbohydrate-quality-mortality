##############causal mediation analysis - top 10 metabolites##############
# https://pubmed.ncbi.nlm.nih.gov/34028370/
# https://bs1125.github.io/CMAverse/reference/cmest.html
library(CMAverse)
library(tidyverse)
library(data.table)
library(haven)

setwd("D:/code and results/article/CARBON-CVD/UKB")
sink("nmr/causal_mediation_NMR.md", append = FALSE)
dt_raw <- read_dta("alldata_new.dta")
dt_raw <- dt_raw %>% 
  mutate(cvd_death_time = (cvd_death_date - baseline_date)/365.25,
         total_death_time = (total_death_date - baseline_date)/365.25,
         nonCVD_death_time = (nonCVD_death_date - baseline_date)/365.25) %>% 
  select("n_eid", "baseline_date",
         "cvd_death","cvd_death_time", 
         "total_death","total_death_time",
         "nonCVD_death","nonCVD_death_time",
         "age","sex","education_int","alcohol_int",
         "pa_int","smoking_int","ethnicity_int","energy","fat_p",
         "protein_p","hypertension","dyslipidemia","diabetes")

nmr_all <- fread("nmr/nmr.txt", fill=T)
nmr_all <- nmr_all %>% 
  select("n_eid","z_carb_fiber",
         "p23478_i0", "p23443_i0", "p23457_i0", "p23456_i0", "p23455_i0", 
         "p23473_i0", "p23450_i0", "p23467_i0", "p23480_i0", "p23632_i0")

dt <- inner_join(dt_raw, nmr_all, by = "n_eid")
dt <- na.omit(dt)

mediators <- c("p23478_i0", "p23443_i0", "p23457_i0", "p23456_i0", "p23455_i0", 
               "p23473_i0", "p23450_i0", "p23467_i0", "p23480_i0", "p23632_i0")
covariates <- c("age","sex","education_int","alcohol_int",
                "pa_int","smoking_int","ethnicity_int","energy","fat_p",
                "protein_p","hypertension","dyslipidemia","diabetes")


# cardiovascular mortality
cat("**********cardiovascular death**********", "\n")
cv_res <- cmest(
  data = dt,
  estimation = "imputation", # method for estimating causal effects
  inference = "bootstrap", # method for estimating standard errors of causal effects
  
  outcome = "cvd_death_time",
  event = "cvd_death", # variable name of the event (used when yreg is coxph, aft_exp, or aft_weibull).
  exposure = "z_carb_fiber", 
  mediator = mediators, # a vector of variable name(s) of the mediator(s).
  EMint = TRUE, # a logical value indicating the existence of exposure-mediator interaction in yreg
  basec = covariates, # a vector of variable name(s) of the exposure-outcome confounder(s), exposure-mediator confounder(s) and mediator-outcome confounder(s) not affected by the exposure
  
  yreg = "coxph", # outcome regression model.
  mreg = list("linear", "linear", "linear", "linear", "linear",
              "linear", "linear", "linear", "linear", "linear"), # a list specifying a regression model for each variable in mediator
  
  a = 1, # the active value for the exposure. Default is 1.
  astar = 0, # the control value for the exposure. Default is 0.   
  mval = list(0,0,0,0,0,0,0,0,0,0), # a list specifying a value for each variable in mediator at which the variable is controlled
  
  nboot = 1000,
  boot.ci.type = "per")
print(summary(cv_res))

# non-cardiovascular mortality
cat("**********non-cardiovascular death**********", "\n")
noncv_res <- cmest(
  data = dt,
  estimation = "imputation", # method for estimating causal effects
  inference = "bootstrap", # method for estimating standard errors of causal effects
  
  outcome = "nonCVD_death_time",
  event = "nonCVD_death", # variable name of the event (used when yreg is coxph, aft_exp, or aft_weibull).
  exposure = "z_carb_fiber", 
  mediator = mediators, # a vector of variable name(s) of the mediator(s).
  EMint = TRUE, # a logical value indicating the existence of exposure-mediator interaction in yreg
  basec = covariates, # a vector of variable name(s) of the exposure-outcome confounder(s), exposure-mediator confounder(s) and mediator-outcome confounder(s) not affected by the exposure
  
  yreg = "coxph", # outcome regression model.
  mreg = list("linear", "linear", "linear", "linear", "linear",
              "linear", "linear", "linear", "linear", "linear"), # a list specifying a regression model for each variable in mediator
  
  a = 1, # the active value for the exposure. Default is 1.
  astar = 0, # the control value for the exposure. Default is 0.   
  mval = list(0,0,0,0,0,0,0,0,0,0), # a list specifying a value for each variable in mediator at which the variable is controlled
  
  nboot = 1000,
  boot.ci.type = "per")
print(summary(noncv_res))

# all-cause mortality
cat("**********total death**********", "\n")
total_res <- cmest(
  data = dt,
  estimation = "imputation", # method for estimating causal effects
  inference = "bootstrap", # method for estimating standard errors of causal effects
  
  outcome = "total_death_time",
  event = "total_death", # variable name of the event (used when yreg is coxph, aft_exp, or aft_weibull).
  exposure = "z_carb_fiber", 
  mediator = mediators, # a vector of variable name(s) of the mediator(s).
  EMint = TRUE, # a logical value indicating the existence of exposure-mediator interaction in yreg
  basec = covariates, # a vector of variable name(s) of the exposure-outcome confounder(s), exposure-mediator confounder(s) and mediator-outcome confounder(s) not affected by the exposure
  
  yreg = "coxph", # outcome regression model.
  mreg = list("linear", "linear", "linear", "linear", "linear",
              "linear", "linear", "linear", "linear", "linear"), # a list specifying a regression model for each variable in mediator
  
  a = 1, # the active value for the exposure. Default is 1.
  astar = 0, # the control value for the exposure. Default is 0.   
  mval = list(0,0,0,0,0,0,0,0,0,0), # a list specifying a value for each variable in mediator at which the variable is controlled
  
  nboot = 1000,
  boot.ci.type = "per")
print(summary(total_res))


sink()

# ############## causal mediation analysis - top 10 metabolites ##############
# library(CMAverse)
# library(tidyverse)
# library(data.table)
# library(haven)
# library(openxlsx)

# setwd("D:/code and results/article/CARBON-CVD/UKB")

# # ------------------------------------------------------------
# # 输出文件名
# # ------------------------------------------------------------
# md_file <- "nmr/causal_mediation_NMR.md"
# xlsx_file <- "nmr/causal_mediation_NMR.xlsx"

# # 开始 markdown 输出
# sink(md_file, append = FALSE, split = TRUE)

# # ------------------------------------------------------------
# # 读入基础数据
# # ------------------------------------------------------------
# dt_raw <- read_dta("alldata_new.dta")

# dt_raw <- dt_raw %>%
#   mutate(
#     cvd_death_time    = as.numeric(cvd_death_date - baseline_date) / 365.25,
#     total_death_time  = as.numeric(total_death_date - baseline_date) / 365.25,
#     nonCVD_death_time = as.numeric(nonCVD_death_date - baseline_date) / 365.25
#   ) %>%
#   select(
#     n_eid, baseline_date,
#     cvd_death, cvd_death_time,
#     total_death, total_death_time,
#     nonCVD_death, nonCVD_death_time,
#     age, sex, education_int, alcohol_int,
#     pa_int, smoking_int, ethnicity_int, energy, fat_p,
#     protein_p, hypertension, dyslipidemia, diabetes
#   )

# # ------------------------------------------------------------
# # 读入 NMR + exposure
# # ------------------------------------------------------------
# nmr_all <- fread("nmr/nmr.txt")

# nmr_all <- nmr_all %>%
#   select(
#     n_eid, z_carb_fiber,
#     p23478_i0, p23443_i0, p23457_i0, p23456_i0, p23455_i0,
#     p23473_i0, p23450_i0, p23467_i0, p23480_i0, p23632_i0
#   )

# # ------------------------------------------------------------
# # 合并 + 缺失值处理
# # ------------------------------------------------------------
# dt <- inner_join(dt_raw, nmr_all, by = "n_eid") %>%
#   na.omit()

# # 避免 Cox/AFT 类模型出现 0 或负的时间
# dt <- dt %>%
#   mutate(
#     cvd_death_time    = ifelse(cvd_death_time <= 0, 0.0001, cvd_death_time),
#     total_death_time  = ifelse(total_death_time <= 0, 0.0001, total_death_time),
#     nonCVD_death_time = ifelse(nonCVD_death_time <= 0, 0.0001, nonCVD_death_time)
#   )

# # ------------------------------------------------------------
# # 变量列表
# # ------------------------------------------------------------
# mediators <- c(
#   "p23478_i0", "p23443_i0", "p23457_i0", "p23456_i0", "p23455_i0",
#   "p23473_i0", "p23450_i0", "p23467_i0", "p23480_i0", "p23632_i0"
# )

# covariates <- c(
#   "age", "sex", "education_int", "alcohol_int",
#   "pa_int", "smoking_int", "ethnicity_int", "energy", "fat_p",
#   "protein_p", "hypertension", "dyslipidemia", "diabetes"
# )

# # ------------------------------------------------------------
# # p 值格式化函数
# # ------------------------------------------------------------
# format_p_value <- function(x) {
#   ifelse(
#     is.na(x), NA,
#     ifelse(x < 2e-16, "<2e-16", formatC(x, format = "f", digits = 4))
#   )
# }

# # ------------------------------------------------------------
# # 方法1：优先直接从 cmest 对象中提取结果
# # 不同版本 CMAverse 可能字段名略有差异，所以这里做兼容
# # ------------------------------------------------------------
# extract_cmest_table_direct <- function(cm_obj, outcome_name) {
#   obj_names <- names(cm_obj)

#   # 尝试几组常见字段名
#   est_name <- intersect(c("effect.pe", "effect_est", "est"), obj_names)
#   se_name  <- intersect(c("effect.se", "effect_se", "se"), obj_names)
#   lcl_name <- intersect(c("effect.ci.low", "effect_ci_low", "ci.low", "lcl"), obj_names)
#   ucl_name <- intersect(c("effect.ci.high", "effect_ci_high", "ci.high", "ucl"), obj_names)
#   p_name   <- intersect(c("effect.pval", "effect_pval", "pval", "p.value"), obj_names)

#   if (length(est_name) == 0 || length(se_name) == 0 ||
#       length(lcl_name) == 0 || length(ucl_name) == 0 || length(p_name) == 0) {
#     return(NULL)
#   }

#   est <- cm_obj[[est_name[1]]]
#   se  <- cm_obj[[se_name[1]]]
#   lcl <- cm_obj[[lcl_name[1]]]
#   ucl <- cm_obj[[ucl_name[1]]]
#   pvl <- cm_obj[[p_name[1]]]

#   if (is.null(names(est))) {
#     return(NULL)
#   }

#   res <- data.frame(
#     Outcome = outcome_name,
#     Term = names(est),
#     Estimate = as.numeric(est),
#     Std.error = as.numeric(se[names(est)]),
#     `95% CIL` = as.numeric(lcl[names(est)]),
#     `95% CIU` = as.numeric(ucl[names(est)]),
#     `P.val` = as.numeric(pvl[names(est)]),
#     check.names = FALSE,
#     row.names = NULL
#   )

#   res
# }

# # ------------------------------------------------------------
# # 方法2：如果 direct 提取失败，则从 summary(cmest) 打印文本解析
# # 这个方法更稳，适合你现在给出的输出格式
# # ------------------------------------------------------------
# extract_cmest_table_from_text <- function(cm_obj, outcome_name) {
#   txt <- capture.output(summary(cm_obj))

#   # 只保留真正的结果行
#   # 结果行通常以 Rcde / Rpnde / ... / pe 开头
#   pattern <- "^(Rcde|Rpnde|Rtnde|Rpnie|Rtnie|Rte|ERcde|ERintref|ERintmed|ERpnie|ERcde\\(prop\\)|ERintref\\(prop\\)|ERintmed\\(prop\\)|ERpnie\\(prop\\)|pm|int|pe)\\s+"
#   dat_lines <- txt[grepl(pattern, txt)]

#   if (length(dat_lines) == 0) {
#     stop("Failed to parse cmest summary output.")
#   }

#   parse_one_line <- function(x) {
#     x2 <- trimws(x)
#     x2 <- gsub("\\*+$", "", x2)   # 去掉末尾显著性星号
#     x2 <- trimws(x2)

#     parts <- strsplit(x2, "\\s+")[[1]]

#     # 目标格式:
#     # Term Estimate Std.error 95% CIL 95% CIU P.val
#     # 比如:
#     # Rcde 1.099924 0.032041 1.038347 1.161 0.004
#     # 或:
#     # Rpnde 1.207857 0.044664 1.126216 1.300 <2e-16

#     if (length(parts) < 6) {
#       return(NULL)
#     }

#     term <- parts[1]
#     estimate <- suppressWarnings(as.numeric(parts[2]))
#     std_error <- suppressWarnings(as.numeric(parts[3]))
#     cil <- suppressWarnings(as.numeric(parts[4]))
#     ciu <- suppressWarnings(as.numeric(parts[5]))
#     pval_chr <- parts[6]

#     pval_num <- suppressWarnings(as.numeric(pval_chr))
#     if (is.na(pval_num) && pval_chr == "<2e-16") {
#       pval_num <- 2e-16
#     }

#     data.frame(
#       Outcome = outcome_name,
#       Term = term,
#       Estimate = estimate,
#       Std.error = std_error,
#       `95% CIL` = cil,
#       `95% CIU` = ciu,
#       `P.val` = pval_num,
#       `P.val (raw)` = pval_chr,
#       check.names = FALSE,
#       row.names = NULL
#     )
#   }

#   res_list <- lapply(dat_lines, parse_one_line)
#   res <- bind_rows(res_list)

#   if (!"P.val (raw)" %in% names(res)) {
#     res$`P.val (raw)` <- format_p_value(res$`P.val`)
#   }

#   res
# }

# # ------------------------------------------------------------
# # 统一提取函数
# # ------------------------------------------------------------
# extract_cmest_table <- function(cm_obj, outcome_name) {
#   res <- tryCatch(
#     extract_cmest_table_direct(cm_obj, outcome_name),
#     error = function(e) NULL
#   )

#   if (is.null(res) || nrow(res) == 0) {
#     res <- extract_cmest_table_from_text(cm_obj, outcome_name)
#   } else {
#     res$`P.val (raw)` <- format_p_value(res$`P.val`)
#   }

#   res
# }

# # ------------------------------------------------------------
# # 跑单个结局
# # ------------------------------------------------------------
# run_cmest_one <- function(data, outcome_time, outcome_event, outcome_label) {
#   cat("\n")
#   cat("############################################################\n")
#   cat("Outcome:", outcome_label, "\n")
#   cat("############################################################\n\n")

#   set.seed(123456)

#   fit <- cmest(
#     data = data,
#     estimation = "imputation",
#     inference = "bootstrap",

#     outcome = outcome_time,
#     event = outcome_event,
#     exposure = "z_carb_fiber",
#     mediator = mediators,
#     EMint = TRUE,
#     basec = covariates,

#     yreg = "coxph",
#     mreg = rep(list("linear"), length(mediators)),

#     a = 1,
#     astar = 0,
#     mval = as.list(rep(0, length(mediators))),

#     nboot = 1000,
#     boot.ci.type = "per"
#   )

#   # markdown 中保留完整 summary 输出
#   print(summary(fit))

#   # 抽取结构化表格
#   tab <- extract_cmest_table(fit, outcome_label)

#   list(
#     fit = fit,
#     table = tab
#   )
# }

# # ------------------------------------------------------------
# # 依次分析三个结局
# # ------------------------------------------------------------
# res_cvd <- run_cmest_one(
#   data = dt,
#   outcome_time = "cvd_death_time",
#   outcome_event = "cvd_death",
#   outcome_label = "cardiovascular death"
# )

# res_noncvd <- run_cmest_one(
#   data = dt,
#   outcome_time = "nonCVD_death_time",
#   outcome_event = "nonCVD_death",
#   outcome_label = "non-cardiovascular death"
# )

# res_total <- run_cmest_one(
#   data = dt,
#   outcome_time = "total_death_time",
#   outcome_event = "total_death",
#   outcome_label = "total death"
# )

# # 关闭 markdown 输出
# sink()

# # ------------------------------------------------------------
# # 整理导出表
# # ------------------------------------------------------------
# cvd_export <- res_cvd$table %>%
#   mutate(`P.val (display)` = ifelse(!is.na(`P.val (raw)`), `P.val (raw)`, format_p_value(`P.val`)))

# noncvd_export <- res_noncvd$table %>%
#   mutate(`P.val (display)` = ifelse(!is.na(`P.val (raw)`), `P.val (raw)`, format_p_value(`P.val`)))

# total_export <- res_total$table %>%
#   mutate(`P.val (display)` = ifelse(!is.na(`P.val (raw)`), `P.val (raw)`, format_p_value(`P.val`)))

# all_results_export <- bind_rows(cvd_export, noncvd_export, total_export)

# # ------------------------------------------------------------
# # 写入 Excel
# # ------------------------------------------------------------
# wb <- createWorkbook()

# addWorksheet(wb, "CVD")
# writeData(wb, "CVD", cvd_export)

# addWorksheet(wb, "NonCVD")
# writeData(wb, "NonCVD", noncvd_export)

# addWorksheet(wb, "Total")
# writeData(wb, "Total", total_export)

# addWorksheet(wb, "all_results")
# writeData(wb, "all_results", all_results_export)

# # 可选：设置列宽更好看
# for (sheet in c("CVD", "NonCVD", "Total", "all_results")) {
#   setColWidths(wb, sheet = sheet, cols = 1:8, widths = "auto")
# }

# saveWorkbook(wb, xlsx_file, overwrite = TRUE)

# cat("\nAnalysis finished successfully.\n")
# cat("Markdown file:", md_file, "\n")
# cat("Excel file:", xlsx_file, "\n")