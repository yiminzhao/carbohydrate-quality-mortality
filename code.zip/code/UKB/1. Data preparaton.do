****import data****
set maxvar 50000
cd "D:\code and results\article\CARBON-CVD\UKB"
use "diet24hrecall_release20.dta", clear   
merge 1:1 n_eid using "death_inpatient_cancer_release20.dta", nogenerate
merge 1:1 n_eid using "first_occurrences.dta", nogenerate
merge 1:1 n_eid using "extracted_variables.dta", nogenerate
merge 1:1 n_eid using "algorithm_defined_release20.dta", nogenerate

************************************1. subject exclusion************************************
*******************************************************
* exclusion log: initialize
*******************************************************
tempname exclog
tempfile exclogfile

postfile `exclog' ///
    str80 step ///
    long n_before ///
    long n_dropped ///
    long n_after ///
    using `exclogfile', replace

capture program drop log_drop
program define log_drop
    syntax , STEP(string) HANDLE(name)

    quietly count
    local n_before = r(N)

    quietly count if __dropflag__ == 1
    local n_dropped = r(N)

    drop if __dropflag__ == 1

    quietly count
    local n_after = r(N)

    post `handle' (`"`step'"') (`n_before') (`n_dropped') (`n_after')

    drop __dropflag__
end

quietly count
post `exclog' (`"Initial sample after main merges"') (r(N)) (0) (r(N))

*extreme energy intake
forvalues x  = 0/4 {    
    replace p26002_i`x' = . if p100020_i`x' == 0
}
egen energy = rowmean(p26002_*)
*conver the unit from KJ to KCal
replace energy = energy / 4.184
// keep n_eid energy 
su n_eid
ren s_53_0_0 baseline_date
ren s_191_0_0 lost_date
ren s_40022_0_0 record_origin

ren p40000_i0 death_date
ren p40001_i0 primary_death_cause
ren p40020_i0 death_origin
egen bmi = rowmean(n_21001_*)
ren n_31_0_0 sex
ren n_21000_0_0 ethnicity
ren n_21022_0_0 age
*******************************************carbohydrate quality*******************************************************
forvalues i  = 0/4 {    
    replace p26008_i`i' =. if p100020_i`i' == 0
    replace p26005_i`i' =. if p100020_i`i' == 0
    replace p26013_i`i' =. if p100020_i`i' == 0
    replace p26017_i`i' =. if p100020_i`i' == 0
    replace p26031_i`i' =. if p100020_i`i' == 0

    replace p26011_i`i' =. if p100020_i`i' == 0
    replace p26012_i`i' =. if p100020_i`i' == 0
    replace p26050_i`i' =. if p100020_i`i' == 0
    replace p26055_i`i' =. if p100020_i`i' == 0
    replace p26056_i`i' =. if p100020_i`i' == 0
}
egen typicaldiet = rowmean(p100020_i*)


egen fat = rowmean(p26008_*)
egen carbohydrate = rowmean(p26013_*)
gen fat_p = (fat * 9 / energy) * 100
gen carb_p = (carbohydrate * 4 / energy) * 100
gen protein_p = 100 - fat_p - carb_p
*grams per day
*****************************************************************
egen fiber = rowmean(p26017_*)
egen min_fiber = min(fiber) if fiber != 0
replace fiber = min_fiber*0.5 if fiber == 0
drop min_fiber
*****************************************************************
gen fiber_p = fiber * 4 / energy *100
gen carb_fiber = carbohydrate / fiber
// centile carb_fiber, centile(0.1 99.9)
// local p1 = r(c_1)
// local p99 = r(c_2)
// drop if (carb_fiber <= `p1' | carb_fiber >= `p99') & !missing(carb_fiber)
centile carb_fiber, centile(0.1 99.9)
local p1 = r(c_1)
local p99 = r(c_2)
*baseline CVD, I20-I25, I50, I48, I60-I64
gen cvd_baseline = 0 
forvalues i = 131296(2)131306 {
    replace cvd_baseline = 1 if p`i' <= baseline_date
}
forvalues i = 131360(2)131368 {
    replace cvd_baseline = 1 if p`i' <= baseline_date
}                                                                             
replace cvd_baseline = 1 if p131350 <= baseline_date | p131354 <= baseline_date
tab cvd_baseline

*baseline cancer
gen cancer_baseline = 0
forvalues i = 0/21{
   replace cancer_baseline = 1 if p40005_i`i' <= baseline_date
}
tab cancer_baseline

*any diabetes, E10-E14
gen diabetes_baseline = 0
forvalues i = 130706(2)130714 {
    replace diabetes_baseline = 1 if p`i' <= baseline_date
}
tab diabetes_baseline

*ersd_baseline
gen ersd_baseline = 0
ren p42026 date_of_ersd_report
replace ersd_baseline = 1 if date_of_ersd_report <= baseline_date
tab ersd_baseline

****droppp***
count if (sex == 1 & (energy < 800 | energy > 4200)) | (sex == 0 & (energy < 600 | energy > 3500))
count if energy==.
count if cvd_baseline == 1
count if cancer_baseline == 1
count if diabetes_baseline == 1
count if ersd_baseline == 1

****dropp log***
gen byte __dropflag__ = typicaldiet == 0
log_drop, step("Exclude: notypicaldiet") handle(`exclog')

gen byte __dropflag__ = (sex == 1 & (energy < 800 | energy > 4200)) | ///
                        (sex == 0 & (energy < 600 | energy > 3500))
log_drop, step("Exclude: extreme energy intake") handle(`exclog')

gen byte __dropflag__ = (carb_fiber <= `p1' | carb_fiber >= `p99') & !missing(carb_fiber)
log_drop, step("Exclude: carb_fiber outside 0.1th-99.9th percentile") handle(`exclog')

gen byte __dropflag__ = (bmi > 45 | bmi < 15)
log_drop, step("Exclude: abnormal BMI ") handle(`exclog')

gen byte __dropflag__ = cvd_baseline == 1
log_drop, step("Exclude: baseline CVD") handle(`exclog')

gen byte __dropflag__ = cancer_baseline == 1
log_drop, step("Exclude: baseline cancer") handle(`exclog')

gen byte __dropflag__ = ersd_baseline == 1
log_drop, step("Exclude: baseline ESRD") handle(`exclog')


// // drop if (sex == 1 & (energy < 800 | energy > 4000)) | (sex == 0 & (energy < 500 | energy > 3500))
// // drop if energy==.
// // drop if cvd_baseline == 1
// // drop if cancer_baseline == 1
// // *drop if diabetes_baseline == 1
// // drop if ersd_baseline == 1
// su n_eid

****************************************2. death identification************************************
*total mortality
gen total_death = 1 if death_date != .
replace total_death = 0 if total_death == .
tab total_death

*primary cause of death
icd10 gen cvd_death = primary_death_cause, range(I00/I789)
tab cvd_death

*secondary cause of death p40002_i0_a0
forvalues i = 0/14 {
    icd10 gen cvd_death_`i' = p40002_i0_a`i', range(I00/I789)
    replace cvd_death = 1 if cvd_death_`i' == 1
    drop cvd_death_`i'
}
replace cvd_death = 0 if cvd_death != 1
tab cvd_death

*nonCVD of death
gen nonCVD_death = 0
replace nonCVD_death = 1 if cvd_death == 0 & total_death == 1
tab nonCVD_death

local outcomes "total_death cvd_death nonCVD_death "  
foreach x of local outcomes {
	gen `x'_date = death_date if death_date != .
	replace `x'_date = lost_date if `x'_date== . & lost_date != .
	replace `x'_date = 23100 if `x'_date == . & record_origin == "HES"
    replace `x'_date = 22796 if `x'_date == . & record_origin=="PEDW"
    replace `x'_date = 22888 if `x'_date == . & record_origin =="SMR"
    replace `x'_date = 23619 if `x'_date == . & death_origin == "E/W"
    replace `x'_date = 23711 if `x'_date == . & death_origin == "SCOT"
    replace `x'_date = 23711 if `x'_date == . 
	*format `x'_date %td
}

// merge 1:1 n_eid using "extracted_variables.dta", nogenerate
*merge 1:1 n_eid using "diet24hrecall_release20.dta", nogenerate
************************************2. rename and label covariates************************************
egen age_cat = cut(age), at(0, 45, 50, 55, 60, 65, 100)
by age_cat, sort: su age
gen age_int = 0
replace age_int =1 if age >= 60
*label 1 "0 <60 years" 1 ">= 60 years"
tab age_int
tab age_cat

*BMI, quintiles
summarize bmi, detail
replace bmi = r(p50) if bmi == .
gen bmi_cat = 9
replace bmi_cat = 1 if bmi < 18.5
replace bmi_cat = 2 if bmi < 25 & bmi >= 18.5
replace bmi_cat = 3 if bmi < 30 & bmi >= 25
replace bmi_cat = 4 if bmi >= 30
tab bmi_cat
gen bmi_int = 1
replace bmi_int = 0 if bmi >= 18.5 & bmi < 25
tab bmi_int

*education
ren n_6138_0_0 education
gen education_int = 0
replace education_int = 1 if education == 1 
tab education_int
*1 "high education"    0"low education"

*alcohol, categorized into sex-specific quintiles
egen alcohol = rowmean(n_26030_*) 
summarize alcohol, detail
replace alcohol = r(p50) if alcohol == .
gen alcohol_int = 1
replace alcohol_int = 0 if alcohol < 22 & sex == 1
replace alcohol_int = 0 if alcohol < 15 & sex == 0
tab alcohol_int

*physical activity, Physical activity ≥ 20 minutes (in the past 12 months) that caused increases in breathing or heart rate, or worked up a sweat.
*ren n_22037_0_0 MET_walk
egen MET_walk = rowmean(n_22037_*)
*ren n_22038_0_0 MET_moderate
egen MET_moderate = rowmean(n_22038_*)
*ren n_22039_0_0 MET_vigorous
egen MET_vigorous = rowmean(n_22039_*)
gen total_MET=(MET_walk+MET_moderate+MET_vigorous)/60
*ren n_864_0_0 Number_days_walked_0
egen Number_days_walked_0 = rowmean(n_864_*)
gen Number_days_walked=Number_days_walked_0 if Number_days_walked_0!=-3 & Number_days_walked_0!=-2 & Number_days_walked_0!=-1
replace Number_days_walked= . if Number_days_walked_0==-3 | Number_days_walked_0==-2 | Number_days_walked_0==-1
*ren n_874_0_0 Duration_of_walks_0
egen Duration_of_walks_0 = rowmean(n_874_*)
gen Duration_of_walks=Duration_of_walks_0 if Duration_of_walks_0!=-3 & Duration_of_walks_0!=-1
replace Duration_of_walks= . if Duration_of_walks_0==-3 | Duration_of_walks_0==-1
*ren n_884_0_0 moderate_PA_times_0
egen moderate_PA_times_0 = rowmean(n_884_*)
gen moderate_PA_times=moderate_PA_times_0 if moderate_PA_times_0!=-3 & moderate_PA_times_0!=-1
replace moderate_PA_times= . if moderate_PA_times_0==-3 | moderate_PA_times_0==-1
label variable moderate_PA_times "Number of days/week of moderate physical activity 10+ minutes"
*ren n_894_0_0 moderate_PA_duration_0
egen moderate_PA_duration_0 = rowmean(n_894_*)
gen moderate_PA_duration=moderate_PA_duration_0 if moderate_PA_duration_0!=-3 & moderate_PA_duration_0!=-1
replace moderate_PA_duration= . if moderate_PA_duration_0==-3 | moderate_PA_duration_0==-1
label variable moderate_PA_duration "Duration of moderate activity(min/wk)"
*ren n_904_0_0 vigorous_PA_times_0
egen vigorous_PA_times_0 = rowmean(n_904_*)
gen vigorous_PA_times=vigorous_PA_times_0 if vigorous_PA_times_0!=-3 & vigorous_PA_times_0!=-1
replace vigorous_PA_times= . if vigorous_PA_times_0==-3 | vigorous_PA_times_0==-1
label variable vigorous_PA_times "Number of days/week of vigorous physical activity 10+ minutes"
*ren n_914_0_0 vigorous_PA_duration_0
egen vigorous_PA_duration_0 = rowmean(n_914_*)
gen vigorous_PA_duration=vigorous_PA_duration_0 if vigorous_PA_duration_0!=-3 & vigorous_PA_duration_0!=-1
replace vigorous_PA_duration= . if vigorous_PA_duration_0==-3 | vigorous_PA_duration_0==-1
label variable vigorous_PA_duration "Duration of vigorous activity(min/wk)"
replace total_MET=(3.3*Duration_of_walks*Number_days_walked+4.0*moderate_PA_duration*moderate_PA_times+8.0*vigorous_PA_duration*vigorous_PA_times)/60 if total_MET== .
egen median_male_MET = median(total_MET) if sex == 1
egen median_female_MET = median(total_MET) if sex == 0
replace total_MET = median_male_MET if sex == 1 & total_MET == .
replace total_MET = median_female_MET if sex == 0 & total_MET == .
egen male_pa_cat = cut(total_MET) if sex == 1, group(5) 
egen female_pa_cat = cut(total_MET) if sex == 0, group(5)
gen pa_cat = male_pa_cat
replace pa_cat = female_pa_cat if pa_cat == .
gen pa_int = 0
replace pa_int = 1 if (moderate_PA_duration>=150 & moderate_PA_duration!= .) | (vigorous_PA_duration>=75 & vigorous_PA_duration!= .) | (moderate_PA_duration+vigorous_PA_duration>=150 & moderate_PA_duration!= . &vigorous_PA_duration!= .) | (moderate_PA_times>=5 & moderate_PA_times!= .) | (vigorous_PA_times>=1 & vigorous_PA_times!= .)
tab pa_int

*race/ethnicity
gen ethnicity_int = 0
replace ethnicity_int = 1 if ethnicity == 1001
tab ethnicity_int
*label define race_label 1 "British white" 2 "others"

*Smoking status
recode n_20116_0_0 (-3 = -1 "Do not know/Prefer not to answer") (0 = 0 "Never") (1 = 1 "Previous") (2 = 2 "Current"), gen(smoking)
replace smoking= 0 if smoking == -1 | smoking == .
gen smoking_int = 0
replace smoking_int = 1 if smoking == 1 | smoking == 2
tab smoking_int 

*****************************************************************
***AHEI-2010****
* 0) 工具：把一组 field id 生成 average_<id>（= rowmean(n_<id>_*））
program define make_avg, rclass
    syntax anything
    foreach fid of local anything {
        unab __vars :  p`fid'_*
        capture confirm var p`fid'_i0
        if _rc==0 {
        egen average_`fid' = rowmean(`__vars')
        }
        else {
            di as err "warning: field `fid' not found; average_`fid' skipped"
        }
        macro drop __vars
    }
end

* 1) 生成各 field 的 average_<id>
make_avg 104060 104070 104080 104090 104100     104130 104140 104150 104160 104170 104180 104190 104200 104210 104220 104230 104240 104250 104260 104270    104290 104300 104310 104320 104330 104340 104350 104360 104370 104380
make_avg 104410 104420 104430 104440 104450 104460 104470 104480 104490 104500 104510 104520 104530 104540 104550 104560 104570 104580 104590
make_avg 103020 103030 103040 103070 103080 103090 103010
make_avg 102410 102420 102430 102440 102450 103270 104000 104010 104110 104120 104280
make_avg 26126 26127 26095
make_avg 100770 100800 100840 100850 102720 102740 101250 101260
make_avg 26155
make_avg 26015 26016
make_avg 26052
*make_avg 26030

* 2) 汇总到 AHEI 组件原始量（与你 R 脚本一致）
egen double vegetables    = rowtotal(average_104060 average_104070 average_104080 average_104090 average_104100 ///
                                     average_104130 average_104140 average_104150 average_104160 average_104170 average_104180 average_104190 average_104200 ///
                                     average_104210 average_104220 average_104230 average_104240 average_104250 average_104260 average_104270 ///
                                     average_104290 average_104300 average_104310 average_104320 average_104330 average_104340 average_104350 average_104360 average_104370 average_104380)

egen double fruits        = rowtotal(average_104410 average_104420 average_104430 average_104440 average_104450 average_104460 average_104470 average_104480 average_104490 average_104500 average_104510 average_104520 average_104530 average_104540 average_104550 average_104560 average_104570 average_104580 average_104590)

egen double red_meat      = rowtotal(average_103020 average_103030 average_103040 average_103070 average_103080 average_103090 average_103010)

egen double nuts_legumes  = rowtotal(average_102410 average_102420 average_102430 average_102440 average_102450 ///
                                     average_103270 average_104000 average_104010 average_104110 average_104120 average_104280)

egen double sugary_drink  = rowtotal(average_26126 average_26127 average_26095)

egen double whole_grain   = rowtotal(average_100770 average_100800 average_100840 average_100850 average_102720 average_102740 average_101250 average_101260)

egen double tfa           = rowtotal(average_26155)
egen double n3fa          = rowtotal(average_26015)
egen double pufa          = rowtotal(average_26015 average_26016)
egen double sodium        = rowtotal(average_26052)
*egen double alcohol       = rowtotal(average_26030)

* 3) 评分：能量调整/密度/分位（复刻你 R 逻辑）
* 3A. residual method 到 2000 kcal：vegetables、fruits、nuts_legumes、whole_grain
local recs vegetables fruits nuts_legumes whole_grain
foreach v of local recs {
    gen double adj_`v' = .
    gen double ln_`v' = ln(`v') if `v' > 0
    quietly regress ln_`v' energy if `v' > 0
    predict double r_`v' if `v' > 0, resid
    replace adj_`v' = r_`v' + _b[_cons] + _b[energy]*2000 if `v' > 0
    drop r_`v' ln_`v'
    xtile q_`v' = adj_`v' if `v' > 0, nq(10)
    gen byte score_`v' = .
    replace score_`v' = 0      if `v' == 0
    replace score_`v' = q_`v'  if `v' > 0
}


* 3B. 能量密度：n3fa、pufa → %E；0→0 分；否则 1..10 分
gen double n3fa_pct = n3fa/energy*100
gen double pufa_pct = pufa/energy*100
foreach v in n3fa_pct pufa_pct {
    xtile q_`v' = `v' if `v' > 0, nq(10)
    gen byte score_`v' = .
    replace score_`v' = 0      if `v' == 0
    replace score_`v' = q_`v'  if `v' > 0
}

* 3C. 限制性：red_meat、sugary_drink、sodium residual 后反向赋分；0→10 分，其余 11-decile
foreach v in red_meat sugary_drink sodium {
    gen double adj_`v' = .
    gen double ln_`v' = ln(`v') if `v' > 0
    quietly regress ln_`v' energy if `v' > 0
    predict double r_`v' if `v' > 0, resid
    replace adj_`v' = r_`v' + _b[_cons] + _b[energy]*2000 if `v' > 0
    drop r_`v' ln_`v'
    xtile q_`v' = adj_`v' if `v' > 0, nq(10)
    gen byte score_`v' = .
    replace score_`v' = 10             if `v' == 0
    replace score_`v' = 10 - q_`v'     if `v' > 0       // 10..1
}

* 3D. 反式脂肪：%E；0→10 分，其余 11-decile
gen double tfa_pct = tfa/energy*100
xtile q_tfa = tfa_pct if tfa_pct > 0, nq(10)
gen byte score_tfa = .
replace score_tfa = 10            if tfa_pct == 0
replace score_tfa = 10 - q_tfa    if tfa_pct > 0

* 3E. 酒精：按你 R 的规则（zero=9；男 0–25、女 0–15 为“良好”=10；其余>0 组内 9-decile）
gen str16 alcohol_flag = ""
replace alcohol_flag = "zero"            if alcohol == 0
replace alcohol_flag = "sex1_good"       if sex==1 & alcohol>0 & alcohol<25
replace alcohol_flag = "sex0_good"       if sex==0 & alcohol>0 & alcohol<15
replace alcohol_flag = "quantile"        if alcohol>0 & alcohol_flag==""

* 分性别计算
xtile alc_dec_male   = alcohol if alcohol_flag=="quantile" & sex==1, nq(9)
xtile alc_dec_female = alcohol if alcohol_flag=="quantile" & sex==0, nq(9)

* 合并为一个变量
gen byte alc_dec = alc_dec_male
replace alc_dec = alc_dec_female if missing(alc_dec)
drop alc_dec_male alc_dec_female


gen byte score_alcohol = .
replace score_alcohol = 9                       if alcohol_flag=="zero"
replace score_alcohol = 10                      if inlist(alcohol_flag,"sex0_good","sex1_good")
replace score_alcohol = 9 - alc_dec             if alcohol_flag=="quantile"
drop alcohol_flag

* 4) 总分
egen double ahei_total = rowtotal( ///
    score_vegetables score_fruits score_nuts_legumes score_whole_grain ///
    score_n3fa_pct score_pufa_pct ///
    score_red_meat score_sugary_drink score_sodium score_tfa ///
    score_alcohol)

summ ahei_total

*quintiles
local scores "carb_p fiber_p carb_fiber  "
foreach score in `scores' {
    egen `score'_cat = cut(`score'), group(5)
    egen q10 = pctile(`score'), p(10)
    egen q90 = pctile(`score'), p(90)
    gen z_`score' = (`score' - q10) / (q90 - q10)
    drop q10 q90
}

* 新增：定义所有cat变量的列表（基于scores生成）
local cat_vars ""
foreach score in `scores' {
    local cat_vars "`cat_vars' `score'_cat z_`score'"  
}

local idvars  n_eid age

local coxs baseline_date death_date age_cat

local outcomes total_death cvd_death nonCVD_death 
local outcomes_date
foreach v of local outcomes {
    local outcomes_date `outcomes_date' `v'_date
}
local all_outcomes `outcomes' `outcomes_date'
display "`all_outcomes'"

local exposures   carb_p fiber_p carb_fiber fiber

local covars  bmi bmi_int sex age_int education_int alcohol_int pa_int ethnicity_int smoking_int energy fat_p protein_p  ahei_total 

local othersvar diabetes_baseline 
keep `idvars' `coxs' `all_outcomes' `exposures' `covars' `othersvar' `cat_vars'
* 9. 保存结果
// // drop if carb_fiber == .
// gen byte __dropflag__ = carb_fiber == .
// log_drop, step("Exclude: missing carb_fiber") handle(`exclog')
save "alldata.dta", replace
***********************************202601 SMuRF***********************************
*Reference:
*Clinical pathway for coronary atherosclerosis in patients without conventional modifiable risk factors
*C-reactive protein and cardiovascular risk in the general population
cd "D:\code and results\article\CARBON-CVD\UKB"
import delimited "smurf_2026-01-20_03-57-13_data.csv", clear
ren eid n_eid
local dates "p53_i0 p130706 p130708"
foreach date of local dates{
    gen `date'_temp = date(`date', "YMD")
    replace `date' = string(`date'_temp)
    drop `date'_temp
    destring `date', replace
}
ren p53_i0 baseline_date

*hypertension
egen sbp = rowmean(p4080_i0_a0 p4080_i0_a1 p93_i0_a0 p93_i0_a1)
egen dbp = rowmean(p4079_i0_a0 p4079_i0_a1 p94_i0_a0 p94_i0_a1)
gen hypertension = 0
replace hypertension = 1 if sbp >= 140 | dbp >= 90
tab hypertension

*dyslipidemia
ren p30690_i0 tc
ren p30780_i0 ldlc
gen dyslipidemia = 0
replace dyslipidemia = 1 if tc > 5.5 | ldlc > 3.5
tab dyslipidemia


*diabetes
ren p30750_i0 hba1c
ren p30740_i0 glucose
egen diabetes_date = rowmin(p130706 p130708)
gen diabetes_icd10 = 1 if diabetes_date <= baseline_date
gen diabetes = 0
replace diabetes = 1 if diabetes_icd10 == 1 | hba1c >= 48 | glucose >= 7
tab diabetes

*current smoker
gen current_smoker = 0
replace current_smoker = 1 if p20116_i0 == "Current"
tab current_smoker
gen smurf = hypertension + dyslipidemia + diabetes + current_smoker
tab smurf
gen smurf_cat = 0
replace smurf_cat = 1 if smurf == 1
replace smurf_cat = 2 if smurf >= 2
keep n_eid smurf hypertension dyslipidemia diabetes current_smoker smurf_cat
save "smurf.dta", replace
use "alldata.dta", clear
merge 1:1 n_eid using "smurf.dta", keep(master match) nogen
save "alldata_new.dta", replace
*******************************************************
* close log and export exclusion summary
*******************************************************
postclose `exclog'
preserve
use `exclogfile', clear
gen step_order = _n
order step_order step n_before n_dropped n_after
list, noobs sep(0)
export excel using "sample_exclusion_summary.xlsx", ///
    firstrow(variables) replace
restore









