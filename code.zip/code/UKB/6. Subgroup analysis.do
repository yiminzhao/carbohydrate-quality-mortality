cd "D:\code and results\article\CARBON-CVD\UKB"
use "alldata_new.dta", clear
local outcomes "cvd_death total_death nonCVD_death"
local exposures "carb_fiber"
foreach outcome of local outcomes{
    
    putexcel set "Results_new.xlsx", sheet("Subgroup_UKB_`outcome'", replace) modify 
    local x = 1
    putexcel A`x'=("Table . Subgroup analysis in the UK Biobank"), left bold
    local x=`x'+1
    putexcel A`x'=("Variable") B`x'=("HR, 95% CI") C`x'=("P for multiplicative interaction") D`x'=("P for additive interaction") E`x'=("RERI")
    putexcel G`x'=("HR") H`x'=("LCI") I`x'=("UCI") 
    local x=`x'+1
    putexcel A`x'=("`outcome'"), left

    stset `outcome'_date, id(n_eid) enter(baseline_date) origin(baseline_date) scale(365.25) failure(`outcome' == 1)

    foreach exposure of local exposures{
        preserve
        local x=`x'+1
        putexcel A`x'=("`exposure'"), left

        su z_`exposure', d
        gen median_`exposure' = 1 if z_`exposure' >= r(p50)
        replace median_`exposure' = 0 if median_`exposure' == .

        * Age, ≥ 60 years versus < 60 years
        local x=`x'+1
        putexcel A`x'=("Age"), left
        local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if age_int == 1
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("≥ 60 years"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if age_int == 0
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("< 60 years"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##i.age_int `covariates'
        estimates store A
        quietly stcox c.z_`exposure' i.age_int `covariates'
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' age_int `covariates'
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * Sex, Men versus women
        local x=`x'+1
        putexcel A`x'=("Sex"), left
        local covariates "education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if sex == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Men"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if sex == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Women"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##sex `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' sex `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' sex `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * Healthy BMI
        local x=`x'+1
        putexcel A`x'=("Healthy BMI"), left
        local covariates "sex education_int alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if bmi_int == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if bmi_int == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##bmi_int `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' bmi_int `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' bmi_int `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * Education
        local x=`x'+1
        putexcel A`x'=("College or university degree"), left
        local covariates "sex alcohol_int pa_int smoking_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if education_int == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if education_int == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##education_int `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' education_int `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' education_int `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")


        * Smoking
        local x=`x'+1
        putexcel A`x'=("Never-smokers"), left
        local covariates "sex education_int alcohol_int pa_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if smoking_int == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if smoking_int == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##smoking_int `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' smoking_int `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' smoking_int `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")


        * Alcohol intake
        local x=`x'+1
        putexcel A`x'=("Excessive alcohol intake"), left
        local covariates "sex education_int smoking_int pa_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if alcohol_int == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if alcohol_int == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##alcohol_int `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' alcohol_int `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' alcohol_int `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * Physical activity
        local x=`x'+1
        putexcel A`x'=("Adequate physical activity"), left
        local covariates "sex education_int smoking_int alcohol_int ethnicity_int energy fat_p protein_p dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if pa_int == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if pa_int == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##pa_int `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' pa_int `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' pa_int `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * hypertension
        local x=`x'+1
        putexcel A`x'=("Hypertension"), left
        local covariates "sex education_int smoking_int alcohol_int pa_int ethnicity_int energy fat_p protein_p dyslipidemia diabetes"

        quietly stcox c.z_`exposure' `covariates' if hypertension == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if hypertension == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##hypertension `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' hypertension `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' hypertension `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * dyslipidemia
        local x=`x'+1
        putexcel A`x'=("Dyslipidemia"), left
        local covariates "sex education_int smoking_int alcohol_int pa_int ethnicity_int energy fat_p protein_p hypertension diabetes"

        quietly stcox c.z_`exposure' `covariates' if dyslipidemia == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if dyslipidemia == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##dyslipidemia `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' dyslipidemia `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' dyslipidemia `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * diabetes
        local x=`x'+1
        putexcel A`x'=("Diabetes"), left
        local covariates "sex education_int smoking_int alcohol_int pa_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia"

        quietly stcox c.z_`exposure' `covariates' if diabetes == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Yes"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if diabetes == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("No"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##diabetes `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' diabetes `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' diabetes `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")


        * SMuRF
        local x=`x'+1
        putexcel A`x'=("Number of SMuRF"), left
        local covariates "sex education_int alcohol_int pa_int ethnicity_int energy fat_p protein_p"

        quietly stcox c.z_`exposure' `covariates' if smurf == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("0"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        quietly stcox c.z_`exposure' `covariates' if smurf == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("1"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure' `covariates' if smurf >= 2, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=(">= 2"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        quietly stcox c.z_`exposure'##i.smurf_cat `covariates', strata(age_cat)
        estimates store A
        quietly stcox c.z_`exposure' i.smurf_cat `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        gen smurf_int = 0 if smurf == 0
        replace smurf_int = 1 if smurf_int == .

        reri stcox median_`exposure' smurf_int `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")

        * Overall diet quality
        local x=`x'+1
        putexcel A`x'=("Healthy eating index"), left
        local covariates "sex education_int smoking_int alcohol_int pa_int ethnicity_int energy fat_p protein_p hypertension dyslipidemia diabetes"
        su ahei_total, d
        gen ahei_int = 1
        replace ahei_int = 0 if ahei_total < r(p50)

        stcox c.z_`exposure' `covariates' if ahei_int == 1, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Above the median"), right
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 
        
        stcox c.z_`exposure' `covariates' if ahei_int == 0, strata(age_cat)
        matrix M = r(table)
        local HR_CI = string(M[1,1],"%9.2f")+" ("+string(M[5,1],"%9.2f")+", "+string(M[6,1],"%9.2f")+")"
        local HR = M[1,1]
        local LCI = M[5,1]
        local UCI = M[6,1]
        local x=`x'+1
        putexcel A`x'=("Below the median"), right 
        putexcel B`x'=("`HR_CI'") G`x'=("`HR'") H`x'=("`LCI'") I`x'=("`UCI'") 

        stcox c.z_`exposure'##ahei_int `covariates', strata(age_cat)
        estimates store A
        stcox c.z_`exposure' ahei_int `covariates', strata(age_cat)
        estimates store B
        lrtest A B
        local p_multiplicative = string(r(p), "%9.3f")
        if r(p) < 0.001 local p_multiplicative "<0.001"

        reri stcox median_`exposure' ahei_int `covariates', strata(age_cat)
        mat M = r(reri_table)
        local RERI = string(M[1,4],"%9.2f")+" ("+string(M[5,4],"%9.2f")+", "+string(M[6,4],"%9.2f")+")"
        local p_additive = string(M[4,4], "%9.3f")
        if M[4,4] < 0.001 local p_additive "<0.001"
        local x=`x'+1
        putexcel C`x'=("`p_multiplicative'") D`x'=("`p_additive'") E`x'=("`RERI'")


        restore

        
    }

}




