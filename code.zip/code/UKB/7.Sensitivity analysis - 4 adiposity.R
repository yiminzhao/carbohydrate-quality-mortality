# # #**********causal mediation analysis**********
# # library(survival)
# # library(mediation)
# # library(haven) 
# # library(tidyverse)

# # setwd("D:/code and results/article/CARBON-CVD/UKB")
   
# # sink("mediation_BMI.md", append = FALSE)
# # dt <- read_dta("alldata_new.dta") 

# # dt <- dt %>% 
# #   select("cvd_death","cvd_death_date",
# #          "total_death","total_death_date",
# #          "nonCVD_death","nonCVD_death_date",
# #          "z_carb_fiber","bmi","baseline_date",
# #          "age","sex","education_int","alcohol_int",
# #          "pa_int","smoking_int","ethnicity_int","energy","fat_p",
# #            "protein_p","hypertension","dyslipidemia","diabetes")
# # dt <- na.omit(dt)

# # #dt$time <- as.numeric((dt$cvd_death_date - dt$baseline_date)/365.25)
# # #class(dt$time)


# # attach(dt)
# # #cvd_death
# # cat("**********cardiovascular death**********", "\n")
# # cvd_death_time <- (cvd_death_date - baseline_date)/365.25
# # med_fit <- lm(bmi ~ z_carb_fiber + sex+age+education_int+
# #                 alcohol_int+pa_int+smoking_int+ethnicity_int+energy+fat_p+
# #                 protein_p+hypertension+dyslipidemia+diabetes)
# # print(summary(med_fit))
# # out_fit <- survreg(Surv(cvd_death_time, cvd_death) ~ z_carb_fiber + bmi + sex+age+education_int+
# #                      alcohol_int+pa_int+smoking_int+ethnicity_int+energy+fat_p+
# #                      protein_p+hypertension+dyslipidemia+diabetes, dist = "weibull")
# # print(summary(out_fit))

# # set.seed(123456)
# # med_result <- mediate(model.m = med_fit, 
# #                       model.y = out_fit, 
# #                       treat = "z_carb_fiber", 
# #                       mediator = "bmi",
# #                       sims = 1000,
# #                       boot = F)
# # print(summary(med_result))

# # #total_death
# # cat("**********total death**********", "\n")
# # total_death_time <- (total_death_date - baseline_date)/365.25
# # med_fit <- lm(bmi ~ z_carb_fiber + sex+age+education_int+
# #                 alcohol_int+pa_int+smoking_int+ethnicity_int+energy+fat_p+
# #                 protein_p+hypertension+dyslipidemia+diabetes)
# # print(summary(med_fit))
# # out_fit <- survreg(Surv(total_death_time, total_death) ~ z_carb_fiber + bmi + sex+age+education_int+
# #                      alcohol_int+pa_int+smoking_int+ethnicity_int+energy+fat_p+
# #                      protein_p+hypertension+dyslipidemia+diabetes, dist = "weibull")
# # print(summary(out_fit))

# # set.seed(123456)
# # med_result <- mediate(model.m = med_fit, 
# #                       model.y = out_fit, 
# #                       treat = "z_carb_fiber", 
# #                       mediator = "bmi",
# #                       sims = 1000,
# #                       boot = F)
# # print(summary(med_result))

# # #nonCVD_death
# # cat("**********non-cardiovascular death**********", "\n")
# # nonCVD_death_time <- (nonCVD_death_date - baseline_date)/365.25
# # med_fit <- lm(bmi ~ z_carb_fiber + sex+age+education_int+
# #                 alcohol_int+pa_int+smoking_int+ethnicity_int+energy+fat_p+
# #                 protein_p+hypertension+dyslipidemia+diabetes)
# # print(summary(med_fit))
# # out_fit <- survreg(Surv(nonCVD_death_time, nonCVD_death) ~ z_carb_fiber + bmi + sex+age+education_int+
# #                      alcohol_int+pa_int+smoking_int+ethnicity_int+energy+fat_p+
# #                      protein_p+hypertension+dyslipidemia+diabetes, dist = "weibull")
# # print(summary(out_fit))

# # set.seed(123456)
# # med_result <- mediate(model.m = med_fit, 
# #                       model.y = out_fit, 
# #                       treat = "z_carb_fiber", 
# #                       mediator = "bmi",
# #                       sims = 1000,
# #                       boot = F)
# # print(summary(med_result))

# # detach(dt)


# # sink()

# # ********** causal mediation analysis **********
# library(survival)
# library(mediation)
# library(haven)
# library(tidyverse)
# library(openxlsx)

# setwd("D:/code and results/article/CARBON-CVD/UKB")

# # 输出 markdown
# sink("mediation_BMI.md", append = FALSE)

# # 读数据
# dt <- read_dta("alldata_new.dta")

# dt <- dt %>%
#   select(
#     cvd_death, cvd_death_date,
#     total_death, total_death_date,
#     nonCVD_death, nonCVD_death_date,
#     z_carb_fiber, bmi, baseline_date,
#     age, sex, education_int, alcohol_int,
#     pa_int, smoking_int, ethnicity_int, energy, fat_p,
#     protein_p, hypertension, dyslipidemia, diabetes
#   ) %>%
#   na.omit()

# # ------------------------------------------------------------
# # 辅助函数：提取 summary(mediate_object) 为 data.frame
# # ------------------------------------------------------------
# extract_mediation_table <- function(med_obj, outcome_name) {
#   sm <- summary(med_obj)

#   res <- data.frame(
#     Outcome = outcome_name,
#     Term = c(
#       "ACME (control)",
#       "ACME (treated)",
#       "ADE (control)",
#       "ADE (treated)",
#       "Total Effect",
#       "Prop. Mediated (control)",
#       "Prop. Mediated (treated)",
#       "ACME (average)",
#       "ADE (average)",
#       "Prop. Mediated (average)"
#     ),
#     Estimate = c(
#       sm$d0, sm$d1,
#       sm$z0, sm$z1,
#       sm$tau.coef,
#       sm$n0, sm$n1,
#       sm$d.avg, sm$z.avg, sm$n.avg
#     ),
#     `95% CI Lower` = c(
#       sm$d0.ci[1], sm$d1.ci[1],
#       sm$z0.ci[1], sm$z1.ci[1],
#       sm$tau.ci[1],
#       sm$n0.ci[1], sm$n1.ci[1],
#       sm$d.avg.ci[1], sm$z.avg.ci[1], sm$n.avg.ci[1]
#     ),
#     `95% CI Upper` = c(
#       sm$d0.ci[2], sm$d1.ci[2],
#       sm$z0.ci[2], sm$z1.ci[2],
#       sm$tau.ci[2],
#       sm$n0.ci[2], sm$n1.ci[2],
#       sm$d.avg.ci[2], sm$z.avg.ci[2], sm$n.avg.ci[2]
#     ),
#     `p-value` = c(
#       sm$d0.p, sm$d1.p,
#       sm$z0.p, sm$z1.p,
#       sm$tau.p,
#       sm$n0.p, sm$n1.p,
#       sm$d.avg.p, sm$z.avg.p, sm$n.avg.p
#     ),
#     check.names = FALSE
#   )

#   res
# }

# # ------------------------------------------------------------
# # 辅助函数：针对一个结局跑中介分析
# # time_var 是事先在 data 里准备好的随访时间变量名
# # ------------------------------------------------------------
# run_mediation <- function(data, outcome_var, time_var, outcome_label) {
#   cat("**********", outcome_label, "**********", "\n")

#   med_fit <- lm(
#     bmi ~ z_carb_fiber + sex + age + education_int +
#       alcohol_int + pa_int + smoking_int + ethnicity_int + energy + fat_p +
#       protein_p + hypertension + dyslipidemia + diabetes,
#     data = data
#   )
#   print(summary(med_fit))

#   out_formula <- as.formula(
#     paste0(
#       "Surv(", time_var, ", ", outcome_var, ") ~ z_carb_fiber + bmi + sex + age + education_int + ",
#       "alcohol_int + pa_int + smoking_int + ethnicity_int + energy + fat_p + ",
#       "protein_p + hypertension + dyslipidemia + diabetes"
#     )
#   )

#   out_fit <- survreg(
#     out_formula,
#     data = data,
#     dist = "weibull"
#   )
#   print(summary(out_fit))

#   set.seed(123456)
#   med_result <- mediate(
#     model.m = med_fit,
#     model.y = out_fit,
#     treat = "z_carb_fiber",
#     mediator = "bmi",
#     sims = 1000,
#     boot = FALSE
#   )
#   print(summary(med_result))

#   res_table <- extract_mediation_table(med_result, outcome_label)

#   list(
#     med_fit = med_fit,
#     out_fit = out_fit,
#     med_result = med_result,
#     table = res_table
#   )
# }

# # ------------------------------------------------------------
# # 构造随访时间（单位：年）
# # ------------------------------------------------------------
# dt <- dt %>%
#   mutate(
#     cvd_death_time = as.numeric(cvd_death_date - baseline_date) / 365.25,
#     total_death_time = as.numeric(total_death_date - baseline_date) / 365.25,
#     nonCVD_death_time = as.numeric(nonCVD_death_date - baseline_date) / 365.25
#   )

# # 为了避免出现 0 或负时间，做一个很小的修正
# dt <- dt %>%
#   mutate(
#     cvd_death_time = ifelse(cvd_death_time <= 0, 0.0001, cvd_death_time),
#     total_death_time = ifelse(total_death_time <= 0, 0.0001, total_death_time),
#     nonCVD_death_time = ifelse(nonCVD_death_time <= 0, 0.0001, nonCVD_death_time)
#   )

# # ------------------------------------------------------------
# # 依次分析三个结局
# # ------------------------------------------------------------
# res_cvd <- run_mediation(dt, "cvd_death", "cvd_death_time", "cardiovascular death")
# res_total <- run_mediation(dt, "total_death", "total_death_time", "total death")
# res_noncvd <- run_mediation(dt, "nonCVD_death", "nonCVD_death_time", "non-cardiovascular death")

# # 结束 markdown 输出
# sink()

# # ------------------------------------------------------------
# # 合并结果表
# # ------------------------------------------------------------
# all_results <- bind_rows(
#   res_cvd$table,
#   res_total$table,
#   res_noncvd$table
# )

# # 可选：格式化 p 值
# format_p <- function(x) {
#   ifelse(
#     is.na(x), NA,
#     ifelse(x < 2e-16, "<2e-16", formatC(x, format = "e", digits = 3))
#   )
# }

# cvd_export <- res_cvd$table %>%
#   mutate(`p-value` = format_p(`p-value`))

# total_export <- res_total$table %>%
#   mutate(`p-value` = format_p(`p-value`))

# noncvd_export <- res_noncvd$table %>%
#   mutate(`p-value` = format_p(`p-value`))

# all_results_export <- all_results %>%
#   mutate(`p-value` = format_p(`p-value`))

# # ------------------------------------------------------------
# # 写入 Excel
# # ------------------------------------------------------------
# wb <- createWorkbook()

# addWorksheet(wb, "CVD")
# writeData(wb, "CVD", cvd_export)

# addWorksheet(wb, "Total")
# writeData(wb, "Total", total_export)

# addWorksheet(wb, "NonCVD")
# writeData(wb, "NonCVD", noncvd_export)

# addWorksheet(wb, "all_results")
# writeData(wb, "all_results", all_results_export)

# saveWorkbook(wb, "mediation_BMI.xlsx", overwrite = TRUE)

# cat("Mediation analysis finished.\n")
# cat("Markdown file: mediation_BMI.md\n")
# cat("Excel file: mediation_BMI.xlsx\n")


##############causal mediation analysis - top 10 metabolites##############
# https://pubmed.ncbi.nlm.nih.gov/34028370/
# https://bs1125.github.io/CMAverse/reference/cmest.html
library(CMAverse)
library(tidyverse)
library(data.table)
library(haven)

setwd("D:/code and results/article/CARBON-CVD/UKB")

sink("cause_mediation_BMI.md", append = FALSE)

dt <- read_dta("alldata_new.dta")
dt <- dt %>% 
  mutate(cvd_death_time = (cvd_death_date - baseline_date)/365.25,
         total_death_time = (total_death_date - baseline_date)/365.25,
         nonCVD_death_time = (nonCVD_death_date - baseline_date)/365.25) %>% 
  select("n_eid", "baseline_date",
         "cvd_death","cvd_death_time",
         "total_death","total_death_time",
         "nonCVD_death","nonCVD_death_time",
         "age","sex","education_int","alcohol_int",
         "pa_int","smoking_int","ethnicity_int","energy","fat_p",
         "protein_p","hypertension","dyslipidemia","diabetes","bmi","z_carb_fiber")

dt <- na.omit(dt)

mediators <- c("bmi")
covariates <- c("age","sex","education_int","alcohol_int",
                "pa_int","smoking_int","ethnicity_int","energy","fat_p",
                "protein_p","hypertension","dyslipidemia","diabetes")


# cardiovascular mortality
cat("**********cardiovascular death**********", "\n")
cv_res <- cmest(
  data = dt,
  estimation = "imputation", # method for estimating causal effects
  inference = "bootstrap", # method for estimating standard errors of causal effects
  
  outcome = "cvd_death_time",
  event = "cvd_death", # variable name of the event (used when yreg is coxph, aft_exp, or aft_weibull).
  exposure = "z_carb_fiber", 
  mediator = mediators, # a vector of variable name(s) of the mediator(s).
  EMint = TRUE, # a logical value indicating the existence of exposure-mediator interaction in yreg
  basec = covariates, # a vector of variable name(s) of the exposure-outcome confounder(s), exposure-mediator confounder(s) and mediator-outcome confounder(s) not affected by the exposure
  
  yreg = "coxph", # outcome regression model.
  mreg = list("linear"), # a list specifying a regression model for each variable in mediator
  
  a = 1, # the active value for the exposure. Default is 1.
  astar = 0, # the control value for the exposure. Default is 0.   
  mval = list(0), # a list specifying a value for each variable in mediator at which the variable is controlled
  
  nboot = 1000,
  boot.ci.type = "per")
print(summary(cv_res))

# non-cardiovascular mortality
cat("**********non-cardiovascular death**********", "\n")
noncv_res <- cmest(
  data = dt,
  estimation = "imputation", # method for estimating causal effects
  inference = "bootstrap", # method for estimating standard errors of causal effects
  
  outcome = "nonCVD_death_time",
  event = "nonCVD_death", # variable name of the event (used when yreg is coxph, aft_exp, or aft_weibull).
  exposure = "z_carb_fiber", 
  mediator = mediators, # a vector of variable name(s) of the mediator(s).
  EMint = TRUE, # a logical value indicating the existence of exposure-mediator interaction in yreg
  basec = covariates, # a vector of variable name(s) of the exposure-outcome confounder(s), exposure-mediator confounder(s) and mediator-outcome confounder(s) not affected by the exposure
  
  yreg = "coxph", # outcome regression model.
  mreg = list("linear"), # a list specifying a regression model for each variable in mediator
  
  a = 1, # the active value for the exposure. Default is 1.
  astar = 0, # the control value for the exposure. Default is 0.   
  mval = list(0), # a list specifying a value for each variable in mediator at which the variable is controlled
  
  nboot = 1000,
  boot.ci.type = "per")
print(summary(noncv_res))

# all-cause mortality
cat("**********total death**********", "\n")
total_res <- cmest(
  data = dt,
  estimation = "imputation", # method for estimating causal effects
  inference = "bootstrap", # method for estimating standard errors of causal effects
  
  outcome = "total_death_time",
  event = "total_death", # variable name of the event (used when yreg is coxph, aft_exp, or aft_weibull).
  exposure = "z_carb_fiber", 
  mediator = mediators, # a vector of variable name(s) of the mediator(s).
  EMint = TRUE, # a logical value indicating the existence of exposure-mediator interaction in yreg
  basec = covariates, # a vector of variable name(s) of the exposure-outcome confounder(s), exposure-mediator confounder(s) and mediator-outcome confounder(s) not affected by the exposure
  
  yreg = "coxph", # outcome regression model.
  mreg = list("linear"), # a list specifying a regression model for each variable in mediator
  
  a = 1, # the active value for the exposure. Default is 1.
  astar = 0, # the control value for the exposure. Default is 0.   
  mval = list(0), # a list specifying a value for each variable in mediator at which the variable is controlled
  
  nboot = 1000,
  boot.ci.type = "per")
print(summary(total_res))


sink()


